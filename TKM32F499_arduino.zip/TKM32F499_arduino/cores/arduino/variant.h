/*
  Copyright (c) 2014 MakerLab.me & Andy Sze(andy.sze.mail@gmail.com)  All right reserved.
  Copyright (c) 2011 Arduino.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#ifndef _VARIANT_MAKERLAB_SUN_
#define _VARIANT_MAKERLAB_SUN_

/*----------------------------------------------------------------------------
 *        Definitions
 *----------------------------------------------------------------------------*/

/** Frequency of the board main oscillator */
#define VARIANT_MAINOSC		12000000

/** Master clock frequency */
#define VARIANT_MCK			240000000

/*----------------------------------------------------------------------------
 *        Headers
 *----------------------------------------------------------------------------*/

#include "Arduino.h"
#ifdef __cplusplus
#include "UARTClass.h"
#endif

#ifdef __cplusplus
extern "C"{
#endif // __cplusplus

/**
 * Libc porting layers
 */
#if defined (  __GNUC__  ) /* GCC CS3 */
//#    include <syscalls.h> /** RedHat Newlib minimal stub */
#endif

#define NONE ((uint8_t)0xFF)

/*----------------------------------------------------------------------------
 *        Pins
 *----------------------------------------------------------------------------*/

// Number of pins defined in PinDescription array
#define PINS_COUNT           (87u)

// LEDs
#define LED_BUILTIN PD8  //定义PD8为默认的一灯大师

#define D4 PA2
#define D3 PA3  //DC
#define D8 PA4  //CS
#define PIN_D3 PA3
#define PIN_D8 PA4

#define PIN_LED_13           (13u)
#define PIN_LED_RXL          -1//(72u)
#define PIN_LED_TXL          -1//(73u)
#define PIN_LED              PIN_LED_13
#define PIN_LED2             PIN_LED_RXL
#define PIN_LED3             PIN_LED_TXL

/*
 * SPI Interfaces
 */
#define SPI_INTERFACES_COUNT 3


#define SPI_INTERFACE_ID     -1//ID_SPI0
#define SPI_CHANNELS_NUM -1//4
//NSS use software control
#define PIN_SPI_SS0          -1//(59u)
#define PIN_SPI_SS1          -1//(60u)
#define PIN_SPI_SS2          -1//(61u)
#define PIN_SPI_SS3          -1//(62u)


#define BOARD_SPI_SS0        -1//(59u)
#define BOARD_SPI_SS1        -1//(60u)
#define BOARD_SPI_SS2        -1//(61u)
#define BOARD_SPI_SS3        -1//PIN_SPI_SS3
#define BOARD_SPI_DEFAULT_SS -1//BOARD_SPI_SS3

#define SPI_INTERFACE1        SPI1
#define PIN_SPI_MOSI1         PB0
#define PIN_SPI_MISO1         PB1
#define PIN_SPI_SCK1          PB2

#define SPI_INTERFACE        SPI2  //as default SPI
#define PIN_SPI_MOSI         PA7  
#define PIN_SPI_MISO         PA6
#define PIN_SPI_SCK          PA5

#define SPI_INTERFACE2        SPI3
#define PIN_SPI_MOSI2         PE15
#define PIN_SPI_MISO2         PE14
#define PIN_SPI_SCK2          PE13


#define BOARD_PIN_TO_SPI_PIN(x) \
	(x==BOARD_SPI_SS0 ? PIN_SPI_SS0 : \
	(x==BOARD_SPI_SS1 ? PIN_SPI_SS1 : \
	(x==BOARD_SPI_SS2 ? PIN_SPI_SS2 : PIN_SPI_SS3 )))
#define BOARD_PIN_TO_SPI_CHANNEL(x) \
	(x==BOARD_SPI_SS0 ? 0 : \
	(x==BOARD_SPI_SS1 ? 1 : \
	(x==BOARD_SPI_SS2 ? 2 : 3)))


#define MOSI  PIN_SPI_MOSI;
#define MISO  PIN_SPI_MISO;
#define SCK   PIN_SPI_SCK;

#define MOSI1  PIN_SPI_MOSI1;
#define MISO1  PIN_SPI_MISO1;
#define SCK1   PIN_SPI_SCK1;

#define MOSI2  PIN_SPI_MOSI2;
#define MISO2  PIN_SPI_MISO2;
#define SCK2   PIN_SPI_SCK2;

/*
 * Wire Interfaces
 */
#define WIRE_INTERFACES_COUNT 2

#define PIN_WIRE_SDA         PB0
#define PIN_WIRE_SCL         PB2
#define WIRE_INTERFACE       I2C1
#define WIRE_INTERFACE_ID    ID_TWI1
#define WIRE_ISR_HANDLER     TWI1_Handler

#define PIN_WIRE1_SDA        (70u)
#define PIN_WIRE1_SCL        (71u)
#define WIRE1_INTERFACE      I2C2
#define WIRE1_INTERFACE_ID   ID_TWI0
#define WIRE1_ISR_HANDLER    TWI0_Handler

/*
 * UART/UART Interfaces
 */
// Serial
#define RX               (0u)  //PA10
#define TX               (1u)  //PA9
// Serial1
#define RX0              (9u) //PA3
#define TX0              (8u) //PA2
// Serial2
#define RX1              (17u) //PD6
#define TX1              (16u) //PD5
// Serial3
#define RX2              (18u) //PD9
#define TX2              (19u) //PD8

/*
 * USB Interfaces
 */
#define PINS_USB             (85u)

/*
 * Analog pins
 */
static const uint8_t A0  = 54;
static const uint8_t A1  = 55;
static const uint8_t A2  = 56;
static const uint8_t A3  = 57;
static const uint8_t A4  = 58;
static const uint8_t A5  = 59;
static const uint8_t A6  = 60;
static const uint8_t A7  = 61;
static const uint8_t A8  = 62;
static const uint8_t A9  = 63;
static const uint8_t A10 = 64;
static const uint8_t A11 = 65;
static const uint8_t DAC0 = 66;
static const uint8_t DAC1 = 67;
static const uint8_t A12 = 66;//same as DAC0
static const uint8_t A13 = 67;//same as DAC1
static const uint8_t A14 = 52;
static const uint8_t A15 = 53;
static const uint8_t CANRX = 68;
static const uint8_t CANTX = 69;
#define ADC_RESOLUTION		12

/*
 * DACC
 */
#define DACC_INTERFACE		DACC
#define DACC_INTERFACE_ID	ID_DACC
#define DACC_RESOLUTION		12
#define DACC_ISR_HANDLER    DACC_Handler
#define DACC_ISR_ID         DACC_IRQn

/*
 * PWM
 */
#define PWM_INTERFACE		PWM
#define PWM_INTERFACE_ID	ID_PWM
#define PWM_FREQUENCY		1000
#define PWM_MAX_DUTY_CYCLE	255
#define PWM_MIN_DUTY_CYCLE	0
#define PWM_RESOLUTION		8

/*
 * TC
 */
#define TC_INTERFACE        TC0
#define TC_INTERFACE_ID     ID_TC0
#define TC_FREQUENCY        1000
#define TC_MAX_DUTY_CYCLE   255
#define TC_MIN_DUTY_CYCLE   0
#define TC_RESOLUTION		8

#ifdef __cplusplus
}
#endif

enum {
			PA10,PA9,							//default UART UART1
			PA11,PA12,PA13,
			PA8,PA0,PA1,
			PA2, PA3,							//UART2
			PA4, PA7, PA6,PA5,		//default SPI  SPI2
			PA14,PA15,
			PB0, PB1, PB2,PB3,PB4,PB5, PB6, PB7,PB8,PB9,PB10, PB11, PB12,PB13, PB14,PB15,
			PC0, PC1, PC2,PC3,PC4,PC5, PC6, PC7,PC8,PC9,PC10, PC11, PC12,PC13, PC14,PC15,
			PD0, PD1, PD2,PD3,PD4,PD5, PD6, PD7,PD8,PD9,PD10, PD11, PD12,PD13, PD14,PD15,
			PE0, PE1, PE2,PE3,PE4,PE5, PE6, PE7,PE8,PE9,PE10, PE11, PE12,PE13, PE14,PE15,PE16,PE17,PE18, PE19, PE20,PE21, PE22,PE23,
	    ADC4,ADC5
	  };
/*----------------------------------------------------------------------------
 *        Arduino objects - C++ only
 *----------------------------------------------------------------------------*/

#ifdef __cplusplus

//extern UARTClass Serial;
extern UARTClass Serial;
extern UARTClass Serial1;
extern UARTClass Serial2;
extern UARTClass Serial3;

#endif

#endif /* _VARIANT_MAKERLAB_SUN_ */

