/*
  Copyright (c) 2014 MakerLab.me & Andy Sze(andy.sze.mail@gmail.com)  All right reserved.
  Copyright (c) 2011 Arduino.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.
  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU Lesser General Public License for more details.
  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
	
	2018.05.04 Ported the project to Keil IDE and modified by wanwenlue@cqut.edu.cn
	Chongqing University of Technology
	No.69 HongGuang Avenue
	400054 Chongqing
	P.R.CHINA
*/

#include "variant.h"
#include "sys.h"

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Pins descriptions
 */
extern const PinDescription g_APinDescription[]=
{
  // 0 .. 53 - Digital pins
  // ----------------------
  // 0/1 - UART (Serial) default UART  UART1
  { GPIOA, GPIO_Pin_10, RCC_AHBPeriph_GPIOA, NONE, NULL, NONE }, //PIN_0, UART1_RX/PA10
  { GPIOA, GPIO_Pin_9,  RCC_AHBPeriph_GPIOA, NONE, NULL, NONE }, //PIN_1, UART1_TX/PA9

  // 2
  { GPIOA, GPIO_Pin_11, RCC_AHBPeriph_GPIOA, NONE, NULL, NONE }, // PIN_2, USB_DP UART5_RX IIC2_SCK
  { GPIOA, GPIO_Pin_12, RCC_AHBPeriph_GPIOA, NONE, NULL, NONE }, // PIN_3, USB_DM UART5_TX IIC2_SDA

  //4~7 
  { GPIOA, GPIO_Pin_13, RCC_AHBPeriph_GPIOA, NONE, NULL, NONE },           // PIN_4, boot MCO_50MHz/PA13
  { GPIOA, GPIO_Pin_8,  RCC_AHBPeriph_GPIOA, NONE, TIM4, TIM_Channel_4 },  // PIN_5, TIM4_CH4/PA8
  { GPIOA, GPIO_Pin_0,  RCC_AHBPeriph_GPIOA, NONE, NULL, NONE },           // PIN_6, Weak up
  { GPIOA, GPIO_Pin_1,  RCC_AHBPeriph_GPIOA, NONE, TIM6, TIM_Channel_1 },  // PIN_7, pwm  (app download)

  //8~9 D3 D4
  { GPIOA, GPIO_Pin_2,   RCC_AHBPeriph_GPIOA, NONE, NULL, NONE }, // PIN 8,USART2_TX
  { GPIOA, GPIO_Pin_3,   RCC_AHBPeriph_GPIOA, NONE, NULL, NONE }, // PIN 9,USART2_RX
	
	//10~13 D5 D6 D7 D8    TK499 SPI2 as arduino default SPI       TK499��SPI2��Ϊarduino��Ĭ��SPI
  { GPIOA, GPIO_Pin_4,   RCC_AHBPeriph_GPIOA, NONE, NULL, NULL }, //PIN 10 SPI2 CS
  { GPIOA, GPIO_Pin_7,   RCC_AHBPeriph_GPIOA, NONE, NULL, NULL }, //PIN 11 SPI2 MOSI 
  { GPIOA, GPIO_Pin_6,   RCC_AHBPeriph_GPIOA, NONE, NULL, NULL }, //PIN 12 SPI2 MISO
  { GPIOA, GPIO_Pin_5,   RCC_AHBPeriph_GPIOA, NONE, NULL, NULL }, //PIN 13 SPI2 SCK 

  //14,15
  { GPIOA, GPIO_Pin_14,  RCC_AHBPeriph_GPIOA, NONE, NULL, NONE},  //PIN 14   SWC
  { GPIOA, GPIO_Pin_15,  RCC_AHBPeriph_GPIOA, NONE, NULL, NONE }, //PIN 15   SWD
	
	
	{ GPIOB, GPIO_Pin_0,  RCC_AHBPeriph_GPIOB, ADC_Channel_0, NULL, NONE }, //PIN 16, IIC1_SDA/SPI1_MOSI/Y-/PB0   
	{ GPIOB, GPIO_Pin_1,  RCC_AHBPeriph_GPIOB, ADC_Channel_1, NULL, NONE }, //PIN 17, SPI1_MISO/X-/PB1   
	{ GPIOB, GPIO_Pin_2,  RCC_AHBPeriph_GPIOB, ADC_Channel_2, NULL, NONE }, //PIN 18, IIC1_SCK/SPI1_SCK/Y+/PB2   
	{ GPIOB, GPIO_Pin_3,  RCC_AHBPeriph_GPIOB, ADC_Channel_3, NULL, NONE }, //PIN 19, SPI1_CS/X+/PB3   
	{ GPIOB, GPIO_Pin_4,  RCC_AHBPeriph_GPIOB, NONE, TIM4, TIM_Channel_1 }, //PIN 20, PB4/TIM4_CH3/DE/CAN2_RX   
	{ GPIOB, GPIO_Pin_5,  RCC_AHBPeriph_GPIOB, NONE, TIM4, TIM_Channel_2 }, //PIN 21, PB5/TIM4_CH2/PCLK/CAN2_TX   
	{ GPIOB, GPIO_Pin_6,  RCC_AHBPeriph_GPIOB, NONE, TIM4, TIM_Channel_3 }, //PIN 22, PB6/TIM4_CH1/HSYNC   
	{ GPIOB, GPIO_Pin_7,  RCC_AHBPeriph_GPIOB, NONE, NULL, NONE },          //PIN 23, PB7/TIM4_ETR/VSYNC   
	
	{ GPIOB, GPIO_Pin_8,  RCC_AHBPeriph_GPIOB, NONE, TIM5, TIM_Channel_1 }, //PIN 24, PB8/RD/CAN1_TX/TIM5_CH1   
	{ GPIOB, GPIO_Pin_9,  RCC_AHBPeriph_GPIOB, NONE, TIM5, TIM_Channel_2 }, //PIN 25, PB9/WR/CAN1_RX/TIM5_CH2   
	{ GPIOB, GPIO_Pin_10,  RCC_AHBPeriph_GPIOB, NONE, NULL, NONE },         //PIN 26, PB10/RS/UART3_TX
	{ GPIOB, GPIO_Pin_11,  RCC_AHBPeriph_GPIOB, NONE, NULL, NONE }, 			  //PIN 27, PB11/CS/UART3_RX  
	{ GPIOB, GPIO_Pin_12,  RCC_AHBPeriph_GPIOB, NONE, NULL, NONE },         //PIN 28, PB12/TK80_BUSY   
	{ GPIOB, GPIO_Pin_13,  RCC_AHBPeriph_GPIOB, NONE, NULL, NONE },         //PIN 29, PB13/TAMPER-RTC   
	{ GPIOB, GPIO_Pin_14,  RCC_AHBPeriph_GPIOB, NONE, TIM7, TIM_Channel_1 },//PIN 30, PB14/TIM7_CH1/OSC32_IN   
	{ GPIOB, GPIO_Pin_15,  RCC_AHBPeriph_GPIOB, NONE, TIM7, TIM_Channel_2 },//PIN 31, PB15/TIM7_CH2/OSC32_OUT   
	
	{ GPIOC, GPIO_Pin_0,  RCC_AHBPeriph_GPIOC, NONE, NULL, NONE }, //PIN 32   PC0/SPI4_CS/IIC3_SDA
	{ GPIOC, GPIO_Pin_1,  RCC_AHBPeriph_GPIOC, NONE, NULL, NONE }, //PIN 33   PC1/SPI4_SCK/IIC3_SCK
	{ GPIOC, GPIO_Pin_2,  RCC_AHBPeriph_GPIOC, NONE, NULL, NONE }, //PIN 34   PC2/SPI4_MISO/SDIO1_D2
	{ GPIOC, GPIO_Pin_3,  RCC_AHBPeriph_GPIOC, NONE, NULL, NONE }, //PIN 35   PC3/SPI4_MOSI/SDIO1_D3/I2S_RX
	{ GPIOC, GPIO_Pin_4,  RCC_AHBPeriph_GPIOC, NONE, NULL, NONE }, //PIN 36   PC4/SDIO1_CMD/I2S_TX
	{ GPIOC, GPIO_Pin_5,  RCC_AHBPeriph_GPIOC, NONE, NULL, NONE }, //PIN 37   PC5/SDIO1_CK/I2S_LRC
	{ GPIOC, GPIO_Pin_6,  RCC_AHBPeriph_GPIOC, NONE, NULL, NONE }, //PIN 38   PC6/SDIO1_D0/I2S_BCLK
	{ GPIOC, GPIO_Pin_7,  RCC_AHBPeriph_GPIOC, NONE, NULL, NONE }, //PIN 39   PC7/SDIO_D1/I2S_MCLK
	
	{ GPIOC, GPIO_Pin_8,  RCC_AHBPeriph_GPIOC, NONE, NULL, NONE },  //PIN 40   Reserved Ԥ��
	{ GPIOC, GPIO_Pin_9,  RCC_AHBPeriph_GPIOC, NONE, NULL, NONE },  //PIN 41   Reserved Ԥ��
	{ GPIOC, GPIO_Pin_10,  RCC_AHBPeriph_GPIOC, NONE, NULL, NONE }, //PIN 42   Reserved Ԥ��
	{ GPIOC, GPIO_Pin_11,  RCC_AHBPeriph_GPIOC, NONE, NULL, NONE }, //PIN 43   Reserved Ԥ�� 
	{ GPIOC, GPIO_Pin_12,  RCC_AHBPeriph_GPIOC, NONE, NULL, NONE }, //PIN 44   Reserved Ԥ�� 
	{ GPIOC, GPIO_Pin_13,  RCC_AHBPeriph_GPIOC, NONE, NULL, NONE }, //PIN 45   Reserved Ԥ�� 
	{ GPIOC, GPIO_Pin_14,  RCC_AHBPeriph_GPIOC, NONE, NULL, NONE }, //PIN 46   Reserved Ԥ�� 
	{ GPIOC, GPIO_Pin_15,  RCC_AHBPeriph_GPIOC, NONE, NULL, NONE }, //PIN 47   Reserved Ԥ�� 
	
	{ GPIOD, GPIO_Pin_0,  RCC_AHBPeriph_GPIOD, NONE, NULL, NONE },           //PIN 48, PD0/TIM2_BKIN/SDIO2_D0   
	{ GPIOD, GPIO_Pin_1,  RCC_AHBPeriph_GPIOD, NONE, NULL, NONE },           //PIN 49, PD1/TIM2_ETR/SDIO2_D1   
	{ GPIOD, GPIO_Pin_2,  RCC_AHBPeriph_GPIOD, NONE, NULL, NONE },           //PIN 50, PD2/TIM2_CH1N/SDIO2_D2   
	{ GPIOD, GPIO_Pin_3,  RCC_AHBPeriph_GPIOD, NONE, NULL, NONE },           //PIN 51, PD3/TIM2_CH2N/SDIO2_D3   
	{ GPIOD, GPIO_Pin_4,  RCC_AHBPeriph_GPIOD, NONE, NULL, NONE },           //PIN 52, PD4/TIM2_CH3N/SDIO2_CK   
	{ GPIOD, GPIO_Pin_5,  RCC_AHBPeriph_GPIOD, NONE, TIM2, TIM_Channel_1 },  //PIN 53, PD5/TIM2_CH1/SDIO2_CMD   
	{ GPIOD, GPIO_Pin_6,  RCC_AHBPeriph_GPIOD, NONE, TIM2, TIM_Channel_2 },  //PIN 54, PD6/TIM2_CH2/UART4_RX   
	{ GPIOD, GPIO_Pin_7,  RCC_AHBPeriph_GPIOD, NONE, TIM2, TIM_Channel_3 },  //PIN 55, PD7/TIM2_CH3/UART4_TX   
	
	{ GPIOD, GPIO_Pin_8,   RCC_AHBPeriph_GPIOD, NONE, TIM2, TIM_Channel_4 }, //PIN 56, PD8/TIM2_CH4      AMBER LED ���� 
	{ GPIOD, GPIO_Pin_9,   RCC_AHBPeriph_GPIOD, NONE, NULL, NONE },          //PIN 57, PD9/QSPI_Q0  
	{ GPIOD, GPIO_Pin_10,  RCC_AHBPeriph_GPIOD, NONE, NULL, NONE },          //PIN 58, PD10/QSPI_SCK   
	{ GPIOD, GPIO_Pin_11,  RCC_AHBPeriph_GPIOD, NONE, NULL, NONE },          //PIN 59, PD11/QSPI_Q3   
	{ GPIOD, GPIO_Pin_12,  RCC_AHBPeriph_GPIOD, NONE, NULL, NONE },          //PIN 60, PD12/QSPI_CS   
	{ GPIOD, GPIO_Pin_13,  RCC_AHBPeriph_GPIOD, NONE, NULL, NONE },          //PIN 61, PD13/QSPI_Q1   
	{ GPIOD, GPIO_Pin_14,  RCC_AHBPeriph_GPIOD, NONE, NULL, NONE },          //PIN 62, PD14/QSPI_Q2   
	{ GPIOD, GPIO_Pin_15,  RCC_AHBPeriph_GPIOD, NONE, NULL, NONE },          //PIN 63, Reserved Ԥ��
	
	{ GPIOE, GPIO_Pin_0,  RCC_AHBPeriph_GPIOE, NONE, NULL, NONE },          //PIN 64, PE0/TIM1_BKIN   
	{ GPIOE, GPIO_Pin_1,  RCC_AHBPeriph_GPIOE, NONE, NULL, NONE },          //PIN 65, PE1/TIM1_ETR   
	{ GPIOE, GPIO_Pin_2,  RCC_AHBPeriph_GPIOE, NONE, NULL, NONE },          //PIN 66, PE2/TIM1_CH1N   
	{ GPIOE, GPIO_Pin_3,  RCC_AHBPeriph_GPIOE, NONE, NULL, NONE },          //PIN 67, PE3/TIM1_CH2N   
	{ GPIOE, GPIO_Pin_4,  RCC_AHBPeriph_GPIOE, NONE, NULL, NONE },          //PIN 68, PE4/TIM1_CH3N   
	{ GPIOE, GPIO_Pin_5,  RCC_AHBPeriph_GPIOE, NONE, TIM1, TIM_Channel_1 }, //PIN 69, PE5/TIM1_CH1   
	{ GPIOE, GPIO_Pin_6,  RCC_AHBPeriph_GPIOE, NONE, TIM1, TIM_Channel_2 }, //PIN 70, PE6/TIM1_CH2   
	{ GPIOE, GPIO_Pin_7,  RCC_AHBPeriph_GPIOE, NONE, TIM1, TIM_Channel_3 }, //PIN 71, PE7/TIM1_CH3   
	
	{ GPIOE, GPIO_Pin_8,   RCC_AHBPeriph_GPIOE, NONE, TIM1, TIM_Channel_4 }, //PIN 72, PE8/TIM1_CH4   
	{ GPIOE, GPIO_Pin_9,   RCC_AHBPeriph_GPIOE, NONE, NULL, NONE },          //PIN 73, PE9/TIM3_ETR   
	{ GPIOE, GPIO_Pin_10,  RCC_AHBPeriph_GPIOE, NONE, TIM3, TIM_Channel_1 }, //PIN 74,PE10/TIM3_CH1    
	{ GPIOE, GPIO_Pin_11,  RCC_AHBPeriph_GPIOE, NONE, TIM3, TIM_Channel_2 }, //PIN 75,PE11/TIM3_CH2    
	{ GPIOE, GPIO_Pin_12,  RCC_AHBPeriph_GPIOE, NONE, NULL, NONE },          //PIN 76,PE12/SPI3_CS    
	{ GPIOE, GPIO_Pin_13,  RCC_AHBPeriph_GPIOE, NONE, NULL, NONE },          //PIN 77,PE13/SPI3_SCK    
	{ GPIOE, GPIO_Pin_14,  RCC_AHBPeriph_GPIOE, NONE, NULL, NONE },          //PIN 78,PE14/SPI3_MISO    
	{ GPIOE, GPIO_Pin_15,  RCC_AHBPeriph_GPIOE, NONE, NULL, NONE },          //PIN 79,PE15/SPI3_MOSI   

	{ GPIOE, GPIO_Pin_16,  RCC_AHBPeriph_GPIOE, NONE, TIM3, TIM_Channel_3 }, //PIN 80,PE16/TIM3_CH3    
	{ GPIOE, GPIO_Pin_17,  RCC_AHBPeriph_GPIOE, NONE, TIM3, TIM_Channel_4 }, //PIN 81,PE17/TIM3_CH4    
	{ GPIOE, GPIO_Pin_18,  RCC_AHBPeriph_GPIOE, NONE, NULL, NONE },          //PIN 82,PE18/IIC3_SDA    
	{ GPIOE, GPIO_Pin_19,  RCC_AHBPeriph_GPIOE, NONE, NULL, NONE },          //PIN 83,PE19/IIC3_SCK    
	{ GPIOE, GPIO_Pin_20,  RCC_AHBPeriph_GPIOE, NONE, NULL, NONE },          //PIN 84,PE20/UART2_RX    
	{ GPIOE, GPIO_Pin_21,  RCC_AHBPeriph_GPIOE, NONE, NULL, NONE },          //PIN 85,PE21/UART2_TX    
	{ GPIOE, GPIO_Pin_22,  RCC_AHBPeriph_GPIOE, NONE, TIM6, TIM_Channel_1 }, //PIN 86,PE22_TIM6_CH1/UART5_RX    
	{ GPIOE, GPIO_Pin_23,  RCC_AHBPeriph_GPIOE, NONE, TIM6, TIM_Channel_2 }, //PIN 87,PE23/TIM6_CH2/UART5_TX   


  // END
  //{ NULL, 0, 0, PIO_NOT_A_PIN, PIo_default, 0, nO_ADC, NO_ADC, NOT_ON_PWM, NOT_ON_TIMER }
} ;


#ifdef __cplusplus
}
#endif

/*
 * UART objects
 */
//UARTClass Serial(UART, UART_IRQn, id_uart, &rx_buffer1);
//void serialEvent() __attribute__((weak));
//void serialEvent() { }
//
//// IT handlers
void UART_Handler(void)
{
 Serial.IrqHandler();
}

// ----------------------------------------------------------------------------
/*
 * UART objects
 */
RingBuffer rx_buffer1;
RingBuffer rx_buffer2;
RingBuffer rx_buffer3;
RingBuffer rx_buffer4;

UARTClass Serial(UART1, UART1_IRQn, id_serial, &rx_buffer1);
void serialEvent() __attribute__((weak));
void serialEvent() { }
UARTClass Serial1(UART1, UART2_IRQn, id_serial1, &rx_buffer2);
void serialEvent1() __attribute__((weak));
void serialEvent1() { }
UARTClass Serial2(UART2, UART3_IRQn, id_serial2, &rx_buffer3);
void serialEvent2() __attribute__((weak));
void serialEvent2() { }
UARTClass Serial3(UART3, UART4_IRQn, id_serial3, &rx_buffer4);
void serialEvent3() __attribute__((weak));
void serialEvent3() { }



// ----------------------------------------------------------------------------

void serialEventRun(void)
{
  if (Serial.available()) serialEvent();
  if (Serial1.available()) serialEvent1();
  if (Serial2.available()) serialEvent2();
  if (Serial3.available()) serialEvent3();
}

// ----------------------------------------------------------------------------

#ifdef __cplusplus
extern "C" {
#endif

void __libc_init_array(void);
	
// IT handlers

void UART1_IRQHandler(void) 
{
	Serial.IrqHandler();//UART1 must be Serial,for UART flash programming.
}

void UART4_IRQHandler(void) 
{
  Serial1.IrqHandler();
}

void UART2_IRQHandler(void) 
{
  Serial2.IrqHandler();
}

void UART3_IRQHandler(void) 
{
  Serial2.IrqHandler();
}	
	
void init( void )
{
	AI_Responder_enable();
	RemapVtorTable();
	SystemClk_HSEInit(RCC_PLLMul_20);//����PLLʱ�ӣ�12MHz*20=240MHz
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);//2��2��ȫ���Ժ�������������һ��


	//TIM10_Config(1000,240);   //��ʱ��10��1ms�ж�һ��
	 SysTick_Config(F_CPU/1000U );
	 NVIC_SetPriority(SysTick_IRQn, 3);
	delay(0);
  // Disable watchdog
  //WDT_Disable(WDT);

  // Initialize C library
  //__libc_init_array();

	//__enable_irq();
  // Initialize Analog Controller

	RCC->APB2ENR |= 0x1<<25;  //��ADCʱ�ӣ���touchpad����ʱ��

	TOUCHPAD->ADCFG =0x3E1E70;      //16��Ƶ   AD�Ƚ�������  21~17λ��ADCԤ��Ƶ��8λ������Ǵ�����Ӧ�ã�Ӧ�÷�Ƶ��һЩ���ַ�Ӧ�Ƚ���
	TOUCHPAD->ADCR = 0x400;      //0x200������ģʽ;0x400����ɨ��ģʽ
	TOUCHPAD->ADCHS = 0x30;      //ͨ��ʹ�� 4��5 ͨ��
	TOUCHPAD->ADCFG |= 0x1;      //ADCʹ��
	TOUCHPAD->ADCR |= (0x1<<8)|(0x1<<3);  //A/Dת����ʼ (ADC start) DMAʹ��
	
}

#ifdef __cplusplus
}
#endif

