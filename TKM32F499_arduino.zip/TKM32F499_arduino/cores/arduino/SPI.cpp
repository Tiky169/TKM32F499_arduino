/*
 * MIT License
 * Copyright (c) 2019 _VIFEXTech
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
#include "SPI.h"


SPIClass::SPIClass(SPI_TypeDef* _SPIx)
{
    SPIx = _SPIx;
}

void SPIClass::SPI_Settings(    SPI_TypeDef* SPIx,
                                uint16_t SPI_Mode_x,
                                uint16_t SPI_DataSize_x,
                                uint16_t SPI_MODEx,
                                uint16_t SPI_NSS_x,
                                uint16_t SPI_BaudRatePrescaler_x,
                                uint16_t SPI_FirstBit_x)
{
    uint16_t SPI_CPOL_x, SPI_CPHA_x;
    SPI_Cmd(SPIx, DISABLE);
	SPI_InitTypeDef SPI_InitStructure;
	
    switch(SPI_MODEx)
    {
    case 0:
        SPI_CPOL_x = SPI_CPOL_Low;
        SPI_CPHA_x = SPI_CPHA_1Edge;
        break;
    case 1:
        SPI_CPOL_x = SPI_CPOL_Low;
        SPI_CPHA_x = SPI_CPHA_2Edge;
        break;
    case 2:
        SPI_CPOL_x = SPI_CPOL_High;
        SPI_CPHA_x = SPI_CPHA_1Edge;
        break;
    case 3:
        SPI_CPOL_x = SPI_CPOL_High;
        SPI_CPHA_x = SPI_CPHA_2Edge;
        break;
    }


    SPI_InitStructure.SPI_Mode = SPI_Mode_x;        //����SPI����ģʽ:(SPI_Mode_Master,SPI_Mode_Slave)
    SPI_InitStructure.SPI_DataSize = SPI_DataSize_x;        //����SPI�����ݴ�С:SPI���ͽ���xλ֡�ṹ
	SPI_InitStructure.SPI_DataWidth = SPI_DataWidth_8b;
    SPI_InitStructure.SPI_CPOL = SPI_CPOL_x;        //ѡ���˴���ʱ�ӵ���̬
    SPI_InitStructure.SPI_CPHA = SPI_CPHA_x;    //���ݲ���ʱ����
    SPI_InitStructure.SPI_NSS = SPI_NSS_Soft;      //NSS�ź���Ӳ����NSS�ܽţ�����������ʹ��SSIλ������:�ڲ�NSS�ź���SSIλ����(SPI_NSS_Soft,SPI_NSS_Hard)
    SPI_InitStructure.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_x;      //���岨����Ԥ��Ƶ��ֵ
    SPI_InitStructure.SPI_FirstBit = SPI_FirstBit_x;    //ָ�����ݴ����MSBλ����LSBλ��ʼ:���ݴ����MSBλ��ʼ(SPI_FirstBit_MSB,SPI_FirstBit_LSB)

    SPI_Init(SPIx, &SPI_InitStructure);  //����SPI_InitStruct��ָ���Ĳ�����ʼ������SPIx�Ĵ���

    SPI_Cmd(SPIx, ENABLE); //ʹ��SPI����
}

void SPIClass::begin(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    if(SPIx == TK499_SPI1)
    {
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_SPI1, ENABLE);  //SPI1 clk enable
		RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOB ,ENABLE);

        GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_2;
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;  //�����������
        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
        GPIO_Init(GPIOB, &GPIO_InitStructure);
				
		GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_1;  		//SPI_MISO
		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU; 		//��������   
		GPIO_Init(GPIOB, &GPIO_InitStructure);
			
		GPIO_PinAFConfig(GPIOB, GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2, GPIO_AF_SPI); //GPIO����ΪSPI
    }
    else if(SPIx == TK499_SPI2)
    {
        RCC_APB2PeriphClockCmd(RCC_APB2Periph_SPI2, ENABLE);  //SPI1 clk enable
		RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA ,ENABLE);
        GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5 | GPIO_Pin_7;
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
        GPIO_Init(GPIOA, &GPIO_InitStructure);
			
		GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_6;  		//SPI_MISO
		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU; 		//��������   
		GPIO_Init(GPIOA, &GPIO_InitStructure);

		GPIO_PinAFConfig(GPIOA, GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7, GPIO_AF_SPI); //GPIO����ΪSPI
    }
    else if(SPIx == TK499_SPI3)
    {
        RCC_APB2PeriphClockCmd(RCC_APB2Periph_SPI3, ENABLE);  //SPI1 clk enable
		RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOE ,ENABLE);
        GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13 | GPIO_Pin_15;
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
        GPIO_Init(GPIOE, &GPIO_InitStructure);
			
		GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_14;  		//SPI_MISO
		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU; 		//��������   
		GPIO_Init(GPIOE, &GPIO_InitStructure);
			
		GPIO_PinAFConfig(GPIOE, GPIO_Pin_13 | GPIO_Pin_14 | GPIO_Pin_15, GPIO_AF_SPI); //GPIO����ΪSPI
    }

    SPI_Settings(   SPIx,
                    SPI_Mode_Master,
                    SPI_DataSize_8b,
                    SPI_MODE3,
                    SPI_NSS_Soft,
                    SPI_BaudRatePrescaler_8,
                    SPI_FirstBit_MSB);

	
		SPI_BiDirectionalLineConfig(SPIx, SPI_Direction_Tx);
		SPI_BiDirectionalLineConfig(SPIx, SPI_Direction_Rx);
		SPI_Cmd(SPIx, ENABLE);
}

void SPIClass::begin(uint32_t clock, uint16_t dataOrder, uint16_t dataMode)
{
    begin();
    setClock(clock);
    setBitOrder(dataOrder);
    setDataMode(dataMode);
    SPI_Cmd(SPIx, ENABLE);
}

void SPIClass::begin(SPISettings settings)
{
    begin();
    setClock(settings.clock);
    setBitOrder(settings.bitOrder);
    setDataMode(settings.dataMode);
    SPI_Cmd(SPIx, ENABLE);
}

void SPIClass::beginSlave(void)
{
    begin();
    SPI_Settings(   SPIx,
                    SPI_Mode_Slave,
                    SPI_DataSize_8b,
                    SPI_MODE0,
                    SPI_NSS_Hard,
                    SPI_BaudRatePrescaler_16,
                    SPI_FirstBit_MSB);
    SPI_Cmd(SPIx, ENABLE);
}

void SPIClass::end(void)
{
    SPI_Cmd(SPIx, DISABLE);
}

void SPIClass::setClock(uint32_t clock)
{
    SPIx->SPBRG = F_CPU / clock;
}
void SPIClass::setFrequency(uint32_t SPI_READ_FREQUENCY)
	{
		SPIx->SPBRG = F_CPU / SPI_READ_FREQUENCY;
	}
void SPIClass::setClockDivider(uint32_t Div) //For AVR(16MHz) compatibility
{
    if(Div == 0)
    {
        setClock(16000000);
    }
    else
    {
        setClock(16000000 / Div);
    }
}

void SPIClass::setBitOrder(uint16_t bitOrder)
{
    if(bitOrder == MSBFIRST)SPI_InitStructure.SPI_FirstBit = SPI_FirstBit_MSB;//MSBFIRST 1
    else SPI_InitStructure.SPI_FirstBit = SPI_FirstBit_LSB;
    SPI_Init(SPIx, &SPI_InitStructure);
    SPI_Cmd(SPIx, ENABLE);
}

/*  Victor Perez. Added to test changing datasize from 8 to 16 bit modes on the fly.
*   Input parameter should be SPI_CR1_DFF set to 0 or 1 on a 32bit word.
*
*/
void SPIClass::setDataSize(uint16_t datasize)
{
    SPI_InitStructure.SPI_DataSize = datasize;
    SPI_Init(SPIx, &SPI_InitStructure);
    SPI_Cmd(SPIx, ENABLE);
}
void SPIClass::SPIM_RX_clear(void)// clear RX buff
{
	SPIx->GCTL &= SPI_Disable_Rx;
	SPIx->GCTL |= SPI_Direction_Rx;
}
void SPIClass::setDataMode(uint8_t dataMode)
{
    /* Notes.  As far as I can tell, the AVR numbers for dataMode appear to match the numbers required by the STM32

    From the AVR doc http://www.atmel.com/images/doc2585.pdf section 2.4

    SPI Mode    CPOL    CPHA    Shift SCK-edge  Capture SCK-edge
    0           0       0       Falling         Rising
    1           0       1       Rising          Falling
    2           1       0       Rising          Falling
    3           1       1       Falling         Rising


    On the STM32 it appears to be

    bit 1 - CPOL : Clock polarity
        (This bit should not be changed when communication is ongoing)
        0 : CLK to 0 when idle
        1 : CLK to 1 when idle

    bit 0 - CPHA : Clock phase
        (This bit should not be changed when communication is ongoing)
        0 : The first clock transition is the first data capture edge
        1 : The second clock transition is the first data capture edge

    If someone finds this is not the case or sees a logic error with this let me know ;-)
     */
    uint16_t SPI_CPOL_x, SPI_CPHA_x;
    SPI_Cmd(SPIx, DISABLE);

    switch(dataMode)
    {
    case SPI_MODE0:
        SPI_CPOL_x = SPI_CPOL_Low;
        SPI_CPHA_x = SPI_CPHA_1Edge;
        break;
    case SPI_MODE1:
        SPI_CPOL_x = SPI_CPOL_Low;
        SPI_CPHA_x = SPI_CPHA_2Edge;
        break;
    case SPI_MODE2:
        SPI_CPOL_x = SPI_CPOL_High;
        SPI_CPHA_x = SPI_CPHA_1Edge;
        break;
    case SPI_MODE3:
        SPI_CPOL_x = SPI_CPOL_High;
        SPI_CPHA_x = SPI_CPHA_2Edge;
        break;
    }

    SPI_InitStructure.SPI_CPOL = SPI_CPOL_x;
    SPI_InitStructure.SPI_CPHA = SPI_CPHA_x;
    SPI_Init(SPIx, &SPI_InitStructure);
    SPI_Cmd(SPIx, ENABLE);
}

void SPIClass::beginTransaction(SPISettings settings)
{

    SPISettings(settings.clock, settings.bitOrder, settings.dataMode);
    setDataSize(settings.dataSize);
    SPI_Cmd(SPIx, ENABLE);
}

void SPIClass::beginTransactionSlave(void)
{
    beginSlave();
}

void SPIClass::endTransaction(void)
{
    SPI_Cmd(SPIx, DISABLE);
}

uint16_t SPIClass::read(void)
{
	//return 1;
	SPI_SendData(SPIx, 0XFF);
    while (1)
	{
		if(SPI_GetFlagStatus(SPIx, SPI_FLAG_RXAVL))	
		{
			return SPI_ReceiveData(SPIx);
		}
	}
}

void SPIClass::read(uint8_t *buf, uint32_t len)
{
    if (len == 0)
        return;


    while((--len))
    {

        noInterrupts();
        SPI_SendData(SPIx, 0XFF);	
				while (1)
				{
					if(SPI_GetFlagStatus(SPIx, SPI_FLAG_RXAVL))	
					{
						 *buf++ = SPI_ReceiveData(SPIx);
					}
				}
        interrupts();
    }

    *buf++ = SPI_ReceiveData(SPIx);
}

void SPIClass::write(uint16_t data)
{
    SPIx->TXREG = data;
	while(!(SPIx->CSTAT&0x01)) {}
}

void SPIClass::write(uint16_t data, uint32_t n)
{
    while ((n--) > 0)
    {
        SPIx->TXREG = data;
		while(!(SPIx->CSTAT&0x01)) {} // wait till Tx empty
    }
}

void SPIClass::write(const uint8_t *data, uint32_t length)
{
    while (length--)
    {
			SPIx->TXREG = *data++;
			while(!(SPIx->CSTAT&0x01)) {} // wait till Tx empty
    }
}

void SPIClass::write(const uint16_t *data, uint32_t length)
{
    while (length--)
    {
        SPIx->TXREG = *data++;
		while(!(SPIx->CSTAT&0x01)) {} // wait till Tx empty
    }
}

uint16_t SPIClass::transfer(uint16_t wr_data) 
{

    SPIx->TXREG = wr_data;
	while(!(SPIx->CSTAT&0x01)) {} // wait till Tx empty

	return SPI_ReceiveData(SPIx);

}

uint16_t SPIClass::transfer16(uint16_t wr_data) const
{
	SPIx->TXREG = wr_data>>8;while(!(SPIx->CSTAT&0x01)) {}
	SPIx->TXREG = wr_data;while(!(SPIx->CSTAT&0x01)) {}
}

uint8_t SPIClass::send(uint8_t data)
{
    this->write(data);
    return 1;
}

uint8_t SPIClass::send(uint8_t *buf, uint32_t len)
{
    this->write(buf, len);
    return len;
}

uint8_t SPIClass::recv(void)
{
    return this->read();
}

SPIClass SPI(TK499_SPI2);  //SCK-PA5 MISO-PA6 MOSI-PA7
SPIClass SPI1(TK499_SPI1); //SCK-PB3 MISO-PB2 MOSI-PB1
SPIClass SPI3(SPI3);       //SCK-PE13 MISO-PE14 MOSI-PE15
