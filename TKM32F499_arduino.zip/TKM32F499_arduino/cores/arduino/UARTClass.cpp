/*
  Copyright (c) 2014 MakerLab.me & Andy Sze(andy.sze.mail@gmail.com)  All right reserved.
  Copyright (c) 2011 Arduino.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
	
	2018.05.04 Ported the project to Keil IDE and modified by wanwenlue@cqut.edu.cn
	Chongqing University of Technology
	No.69 HongGuang Avenue
	400054 Chongqing
	P.R.CHINA
*/

//#include <stdlib.h>
//#include <stdio.h>
//#include <string.h>
#include "Arduino.h"
#include "UARTClass.h"


extern "C"{


// Constructors ////////////////////////////////////////////////////////////////

UARTClass::UARTClass( UART_TypeDef* pUART, IRQn_Type dwIrq, uint32_t dwId, RingBuffer* pRx_buffer )
{
  _rx_buffer = pRx_buffer ;

  _pUART=pUART ;
  _dwIrq=dwIrq ;
  _dwId=dwId ;
}

// Public Methods //////////////////////////////////////////////////////////////

void UARTClass::begin( const uint32_t dwBaudRate )
{
	GPIO_InitTypeDef  GPIO_InitStructure;
  
  if(_dwId == id_serial)//Serial=UART1
  {
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_UART1, ENABLE);
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA, ENABLE);
	GPIO_PinAFConfig(GPIOA, GPIO_Pin_9 | GPIO_Pin_10, GPIO_AF_UART_1); //PA9、PA10复用为串口1
  }
  else if(_dwId == id_serial1)//Serial1
  {
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_UART2, ENABLE);
	GPIO_PinAFConfig(GPIOA, GPIO_Pin_2 | GPIO_Pin_3, GPIO_AF_UART_2345); //PA2、PA3复用为串口2
  }
  else if(_dwId == id_serial2)//Serial2
  {

  }

  else if(_dwId == id_serial3)//Serial3
  {
//    pinMode(RX2, INPUT);
//    pinMode(TX2, AF_OUTPUT_PUSHPULL);
  }

	// UART default configuration
	// UART configured as follow:
	// - BaudRate = (set baudRate as 9600 baud)
	// - Word Length = 8 Bits
	// - One Stop Bit
	// - No parity
	// - Hardware flow control disabled (RTS and CTS signals)
	// - Receive and transmit enabled
	UART_InitStructure.UART_BaudRate = dwBaudRate; //波特率
	UART_InitStructure.UART_WordLength = UART_WordLength_8b;//数据位
	UART_InitStructure.UART_StopBits = UART_StopBits_1;//停止位
	UART_InitStructure.UART_Parity = UART_Parity_No ;
	UART_InitStructure.UART_Mode = UART_Mode_Rx | UART_Mode_Tx;//输入输出模式
	UART_InitStructure.UART_HardwareFlowControl = UART_HardwareFlowControl_None; 
	// Configure UART
	UART_Init(_pUART, &UART_InitStructure);
	// Enable the UART
	UART_Cmd(_pUART, ENABLE);
	  
	UART_ClearITPendingBit(_pUART, 0xff); 
	UART_ITConfig(_pUART, UART_IT_RXIEN, ENABLE);//使能接收中断
	NVIC_SetPriority(_dwIrq,3);
	NVIC_EnableIRQ(_dwIrq);
	
	//注意一下初始化顺序，引脚最后打开，避免首字母打印乱码
	if(_dwId == id_serial)//Serial=UART1
  {
	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_9;   //uart1_tx  pa9
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP; // 推免复用输出
	GPIO_Init(GPIOA, &GPIO_InitStructure);

	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_10;  //uart1_rx  pa10
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU; //上拉输入   
	GPIO_Init(GPIOA, &GPIO_InitStructure);
  }
  else if(_dwId == id_serial1)//Serial1
  {	
	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_2;   //uart2_tx  PA2
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP; // 推免复用输出
	GPIO_Init(GPIOA, &GPIO_InitStructure);

	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_3;  //uart2_rx  PA3
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU; //上拉输入   
	GPIO_Init(GPIOA, &GPIO_InitStructure);		
  }
  else if(_dwId == id_serial2)//Serial2
  {

  }

  else if(_dwId == id_serial3)//Serial3
  {
//    pinMode(RX2, INPUT);
//    pinMode(TX2, AF_OUTPUT_PUSHPULL);
  }
}

void UARTClass::end( void )
{
  // clear any received data
  _rx_buffer->_iHead = _rx_buffer->_iTail ;

  // Disable UART interrupt in NVIC
  NVIC_DisableIRQ( _dwIrq ) ;

  // Wait for any outstanding data to be sent
  flush();
  
  UART_Cmd(_pUART, DISABLE);

  if(_dwId == id_serial)//Serial
  {
    // Disable UART Clock
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_UART1, DISABLE);
  }
  else if(_dwId == id_serial2)//Serial2
  {
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_UART2, DISABLE);
  }
  else if(_dwId == id_serial3)//Serial3
  {
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_UART3, DISABLE);
  }
  else if(_dwId == id_serial1)//Serial1
  {
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_UART4, DISABLE);
  }
}

int UARTClass::available( void )
{
  return (uint32_t)(SERIAL_BUFFER_SIZE + _rx_buffer->_iHead - _rx_buffer->_iTail) % SERIAL_BUFFER_SIZE ;
}

int UARTClass::peek( void )
{
  if ( _rx_buffer->_iHead == _rx_buffer->_iTail )
    return -1 ;

  return _rx_buffer->_aucBuffer[_rx_buffer->_iTail] ;
}

int16_t UARTClass::read( void )
{
  // if the head isn't ahead of the tail, we don't have any characters
  if ( _rx_buffer->_iHead == _rx_buffer->_iTail )
    return -1 ;

  uint8_t uc = _rx_buffer->_aucBuffer[_rx_buffer->_iTail] ;
  _rx_buffer->_iTail = (unsigned int)(_rx_buffer->_iTail + 1) % SERIAL_BUFFER_SIZE ;
  return uc ;
}

void UARTClass::flush( void )
{
  _rx_buffer->_iTail = _rx_buffer->_iHead;
}

size_t UARTClass::write( const uint8_t uc_data )
{

	// Send one byte from UART
	while((_pUART->CSR &0x1) == 0);
	_pUART->TDR = uc_data;
	return 1;
}

void UARTClass::IrqHandler( void )
{
  // Did we receive data ?
  if(_pUART->ISR & (1<<1))
  {
	_pUART->ICR |= 1<<1;
	/* Read one byte from the receive data register */
    _rx_buffer->store_char( _pUART->RDR ) ;

  }
}

}