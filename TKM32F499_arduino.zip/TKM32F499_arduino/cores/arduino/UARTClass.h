/*
  Copyright (c) 2014 MakerLab.me & Andy Sze(andy.sze.mail@gmail.com)  All right reserved.
  Copyright (c) 2011 Arduino.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
  See the GNU Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#ifndef UARTCLASS_H
#define UARTCLASS_H

#include "HardwareSerial.h"
#include "RingBuffer.h"

// Includes Atmel CMSIS
//#include <chip.h>
#include "tk499.h" 
#include "HAL_conf.h"



#define id_serial  0
#define id_serial1 1
#define id_serial2 2
#define id_serial3 3


class UARTClass   :public Stream    //: public HardwareSerial
{
  protected:
    RingBuffer *_rx_buffer ;

  protected:
    UART_TypeDef* _pUART ;
    UART_InitTypeDef UART_InitStructure ;
    IRQn_Type _dwIrq ;
    uint32_t _dwId ;

  public:
    //USARTClass( Usart* pUsart, IRQn_Type dwIrq, uint32_t dwId, RingBuffer* pRx_buffer ) ;
    UARTClass( UART_TypeDef* pUart, IRQn_Type dwIrq, uint32_t dwId, RingBuffer* pRx_buffer ) ;

     void begin( const uint32_t dwBaudRate ) ;
     void end( void ) ;
     virtual int available( void ) ;
     virtual int peek( void ) ;
     virtual int16_t read( void ) ;
     virtual void flush( void ) ;	  
     virtual size_t write( const uint8_t c ) ;
     using Print::write;
     void IrqHandler( void ) ;

#if defined __GNUC__ /* GCC CS3 */
//     using Print::write ; // pull in write(str) and write(buf, size) from Print
#elif defined __ICCARM__ /* IAR Ewarm 5.41+ */
//    virtual void write( const char *str ) ;
//    virtual void write( const uint8_t *buffer, size_t size ) ;
#endif

    //operator bool() { return true; }; // USART always active
};

#endif 
