extern unsigned int touch_ADC_on;
extern unsigned int TOUCH_X,TOUCH_Y;

void Touch_Pad_Config(void);


char touch_region(int x,int y,int xlong,int ylong);
char touch_long_press(void);

