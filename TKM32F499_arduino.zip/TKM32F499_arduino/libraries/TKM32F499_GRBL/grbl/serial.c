/*
  serial.c - Low level functions for sending and recieving bytes via the serial port
  Part of Grbl

  Copyright (c) 2011-2016 Sungeun K. Jeon for Gnea Research LLC
  Copyright (c) 2009-2011 Simen Svale Skogsrud

  Grbl is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  Grbl is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with Grbl.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "grbl.h"
#include "usblib/usb.h"
#include <stdio.h>


uint8_t serial_rx_buffer[RX_RING_BUFFER];
uint8_t serial_rx_buffer_head = 0;
volatile uint8_t serial_rx_buffer_tail = 0;

uint8_t serial_tx_buffer[TX_RING_BUFFER];
//uint8_t serial_tx_buffer_head = 0;
//volatile uint8_t serial_tx_buffer_tail = 0;


// Returns the number of bytes available in the RX serial buffer.
uint8_t serial_get_rx_buffer_available(void)
{
  uint8_t rtail = serial_rx_buffer_tail; // Copy to limit multiple calls to volatile
  if (serial_rx_buffer_head >= rtail) { return(RX_BUFFER_SIZE - (serial_rx_buffer_head-rtail)); }
  return((rtail-serial_rx_buffer_head-1));
}


// Returns the number of bytes used in the RX serial buffer.
// NOTE: Deprecated. Not used unless classic status reports are enabled in config.h.
uint8_t serial_get_rx_buffer_count(void)
{
  uint8_t rtail = serial_rx_buffer_tail; // Copy to limit multiple calls to volatile
  if (serial_rx_buffer_head >= rtail) { return(serial_rx_buffer_head-rtail); }
  return (RX_BUFFER_SIZE - (rtail-serial_rx_buffer_head));
}


// Returns the number of bytes used in the TX serial buffer.
// NOTE: Not used except for debugging and ensuring no TX bottlenecks.
//uint8_t serial_get_tx_buffer_count(void)
//{
//  uint8_t ttail = serial_tx_buffer_tail; // Copy to limit multiple calls to volatile
//  if (serial_tx_buffer_head >= ttail) { return(serial_tx_buffer_head-ttail); }
//  return (TX_RING_BUFFER - (ttail-serial_tx_buffer_head));
//}


void serial_init(void)
{
  UART_InitTypeDef       UART_InitStructure;  
	GPIO_InitTypeDef  GPIO_InitStructure;   
	NVIC_InitTypeDef NVIC_InitStructure;                 //�ж����ȼ��������Ͷ���ṹ��
	
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_UART1, ENABLE);
	
	GPIO_PinAFConfig(GPIOA, GPIO_Pin_9 | GPIO_Pin_10, GPIO_AF_UART_1); //PA9��PA10����Ϊ����1	

	UART_InitStructure.UART_BaudRate = 115200; //������
  UART_InitStructure.UART_WordLength = UART_WordLength_8b;//����λ
  UART_InitStructure.UART_StopBits = UART_StopBits_1;//ֹͣλ
  UART_InitStructure.UART_Parity = UART_Parity_No ;
  UART_InitStructure.UART_Mode = UART_Mode_Rx | UART_Mode_Tx;//�������ģʽ
  UART_InitStructure.UART_HardwareFlowControl = UART_HardwareFlowControl_None; 	
	UART_Init(UART1, &UART_InitStructure);
	UART_Cmd(UART1, ENABLE);  //UART ģ��ʹ��
	UART_ClearITPendingBit(UART1, 0xff); 
	
	// UART_ITConfig(UART1, UART_IT_RXIEN, ENABLE);//ʹ�ܽ����ж�UART_IT_TXIEN
	
	////UART1 NVIC ����
	// NVIC_InitStructure.NVIC_IRQChannel = UART1_IRQn;       //����1�ж�ͨ��
	// NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=3; //��ռ���ȼ�3
	// NVIC_InitStructure.NVIC_IRQChannelSubPriority =3;       //�����ȼ�3
	// NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;	        //IRQͨ��ʹ��
	// NVIC_Init(&NVIC_InitStructure);	                        //����ָ���Ĳ�����ʼ��NVIC�Ĵ���
	// NVIC_SetPriority(UART1_IRQn,3);
	// NVIC_EnableIRQ(UART1_IRQn);
	
	
	//ע���ʼ��˳���������򿪣��������ַ���ӡ����
  GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_9;   //uart1_tx  pa9
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP; // ���⸴�����
  GPIO_Init(GPIOA, &GPIO_InitStructure);

  GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_10;  //uart1_rx  pa10
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU; //��������   
  GPIO_Init(GPIOA, &GPIO_InitStructure); //��������1�ж�

  // defaults to 8-bit, no parity, 1 stop bit
}
extern unsigned char ep1_Tx_dataBuf[256];
extern unsigned int ep1_Tx_dataLen;

#pragma arm section code ="RAMCODE"
// Writes one byte to the TX serial buffer. Called by main program.
uint32_t USB_tx_buffer_head = 0;//���ο������������4,294,967,296(Լ42���ֽڣ���4GB����)
uint32_t USB_tx_buffer_tail = 0;
uint32_t LCD_tx_buffer_head = 0;
uint32_t LCD_tx_buffer_tail = 0;
uint8_t LCD_tx_buffer[4096];
void serial_write(uint8_t data) {
	
//	while((UART1->CSR &0x1) == 0);
//	UART1->TDR = data;
	 serial_tx_buffer[USB_tx_buffer_head&0xff] = data;
	 LCD_tx_buffer[LCD_tx_buffer_head&0xfff] = data;
	 LCD_tx_buffer_head++;
	 USB_tx_buffer_head++;
	
}

extern unsigned char ep3_rx_flag;

uint32_t LCD_rx_buffer_head = 0;
uint32_t LCD_rx_buffer_tail = 0;
uint8_t LCD_rx_buffer[1024];
void grbl_rx_data_Decode(uint8_t data)
{
	uint8_t next_head;
	// Pick off realtime command characters directly from the serial stream. These characters are
  // not passed into the main buffer, but these set system state flag bits for realtime execution.
  switch (data) {
    case CMD_RESET:         mc_reset(); break; // Call motion control reset routine.
    case CMD_STATUS_REPORT: system_set_exec_state_flag(EXEC_STATUS_REPORT); break; // Set as true
    case CMD_CYCLE_START:   system_set_exec_state_flag(EXEC_CYCLE_START); break; // Set as true
    case CMD_FEED_HOLD:     system_set_exec_state_flag(EXEC_FEED_HOLD); break; // Set as true
    default :
      if (data > 0x7F) { // Real-time control characters are extended ACSII only.
        switch(data) {
          case CMD_SAFETY_DOOR:   system_set_exec_state_flag(EXEC_SAFETY_DOOR); break; // Set as true
          case CMD_JOG_CANCEL:   
            if (sys.state & STATE_JOG) { // Block all other states from invoking motion cancel.
              system_set_exec_state_flag(EXEC_MOTION_CANCEL); 
            }
            break; 
          #ifdef DEBUG
            case CMD_DEBUG_REPORT: {uint8_t sreg = SREG; cli(); bit_true(sys_rt_exec_debug,EXEC_DEBUG_REPORT); SREG = sreg;} break;
          #endif
          case CMD_FEED_OVR_RESET: system_set_exec_motion_override_flag(EXEC_FEED_OVR_RESET); break;
          case CMD_FEED_OVR_COARSE_PLUS: system_set_exec_motion_override_flag(EXEC_FEED_OVR_COARSE_PLUS); break;
          case CMD_FEED_OVR_COARSE_MINUS: system_set_exec_motion_override_flag(EXEC_FEED_OVR_COARSE_MINUS); break;
          case CMD_FEED_OVR_FINE_PLUS: system_set_exec_motion_override_flag(EXEC_FEED_OVR_FINE_PLUS); break;
          case CMD_FEED_OVR_FINE_MINUS: system_set_exec_motion_override_flag(EXEC_FEED_OVR_FINE_MINUS); break;
          case CMD_RAPID_OVR_RESET: system_set_exec_motion_override_flag(EXEC_RAPID_OVR_RESET); break;
          case CMD_RAPID_OVR_MEDIUM: system_set_exec_motion_override_flag(EXEC_RAPID_OVR_MEDIUM); break;
          case CMD_RAPID_OVR_LOW: system_set_exec_motion_override_flag(EXEC_RAPID_OVR_LOW); break;
          case CMD_SPINDLE_OVR_RESET: system_set_exec_accessory_override_flag(EXEC_SPINDLE_OVR_RESET); break;
          case CMD_SPINDLE_OVR_COARSE_PLUS: system_set_exec_accessory_override_flag(EXEC_SPINDLE_OVR_COARSE_PLUS); break;
          case CMD_SPINDLE_OVR_COARSE_MINUS: system_set_exec_accessory_override_flag(EXEC_SPINDLE_OVR_COARSE_MINUS); break;
          case CMD_SPINDLE_OVR_FINE_PLUS: system_set_exec_accessory_override_flag(EXEC_SPINDLE_OVR_FINE_PLUS); break;
          case CMD_SPINDLE_OVR_FINE_MINUS: system_set_exec_accessory_override_flag(EXEC_SPINDLE_OVR_FINE_MINUS); break;
          case CMD_SPINDLE_OVR_STOP: system_set_exec_accessory_override_flag(EXEC_SPINDLE_OVR_STOP); break;
          case CMD_COOLANT_FLOOD_OVR_TOGGLE: system_set_exec_accessory_override_flag(EXEC_COOLANT_FLOOD_OVR_TOGGLE); break;
          #ifdef ENABLE_M7
            case CMD_COOLANT_MIST_OVR_TOGGLE: system_set_exec_accessory_override_flag(EXEC_COOLANT_MIST_OVR_TOGGLE); break;
          #endif
        }
        // Throw away any unfound extended-ASCII character by not passing it to the serial buffer.
      } else { // Write character to buffer
        next_head = serial_rx_buffer_head + 1;
        if (next_head == RX_RING_BUFFER) { next_head = 0; }

        // Write data to buffer unless it is full.
        if (next_head != serial_rx_buffer_tail) {
          serial_rx_buffer[serial_rx_buffer_head] = data;
          serial_rx_buffer_head = next_head;
        }
      }
		}
}
void USB_to_grbl(void)  
{
	unsigned int i, temp_len;
	uint8_t data;
	
    if(ep3_rx_flag == 1)					//����buf�ǿ�
    {
        temp_len = USB->rEP3_AVIL & 0x7f;
        for(i = 0; i < temp_len; i++)
        {
            data = USB->rEP3_FIFO;
						LCD_rx_buffer[LCD_rx_buffer_head&0x3ff] = data;
						LCD_rx_buffer_head++;
						grbl_rx_data_Decode(data);
        }
        ep3_rx_flag = 0;
    }
		//////////////////======////////////////

}

//void offline_uart(float x,float y)
//{
//	uint8_t next_head;
//	char temp[50];
//	int i=0;
//	 // Write character to buffer  $J=G21G91X0.000Y-10.000Z0.000F1000
//	sprintf(temp,"$J=G21G91X%fY%fZ0.000F1000",x,y);
//	while(temp[i])
//	{
//        next_head = serial_rx_buffer_head + 1;
//        if (next_head == RX_RING_BUFFER) { next_head = 0; }

//        // Write data to buffer unless it is full.
//        if (next_head != serial_rx_buffer_tail) {
//          serial_rx_buffer[serial_rx_buffer_head] = temp[i];
//          serial_rx_buffer_head = next_head;
//        }
//				i++;
//		}

//}
// Fetches the first byte in the serial read buffer. Called by main program.
uint8_t serial_read()
{
  uint8_t tail = serial_rx_buffer_tail; // Temporary serial_rx_buffer_tail (to optimize for volatile)
  if (serial_rx_buffer_head == tail) {
    return SERIAL_NO_DATA;
  } else {
    uint8_t data = serial_rx_buffer[tail];

    tail++;
    if (tail == RX_RING_BUFFER) { tail = 0; }
    serial_rx_buffer_tail = tail;

    return data;
  }
}
#pragma arm section
//�������ܣ�ʵ���������������ƶ�����
//axis������0��1��2��  d���ƶ��ľ���mm
void offline_uart(uint8_t axis,float xyz_data)  //�ر�˵�����������д�ӡ����ģ�һ��Ҫ��ͷ�ļ������������void offline_uart(char axis,float d);�������C�ļ��������û�������ĺ������������KEIL�������е����������ʱ�Ҳ���ԭ��
{
	char temp[30];	
	unsigned char i=0;
	
	if(axis==0)sprintf(temp,"$J=G21 G91 X%.3f F1000\r\n",xyz_data);
	if(axis==1)sprintf(temp,"$J=G21 G91 Y%.3f F1000\r\n",xyz_data);
	if(axis==2)sprintf(temp,"$J=G21 G91 Z%.3f F1000\r\n",xyz_data);

	while(temp[i])
        {
            axis = temp[i++];//axis �˴���Ϊ��ʱ����
						LCD_rx_buffer[LCD_rx_buffer_head&0x3ff] = axis;
						LCD_rx_buffer_head++;
						grbl_rx_data_Decode(axis);
        }
}
void CMD_uart(char *s)
	{	
	uint8_t data;

	while(*s)
        {
            data = *s++;
						LCD_rx_buffer[LCD_rx_buffer_head&0x3ff] = data;
						LCD_rx_buffer_head++;
						grbl_rx_data_Decode(data);
        }
}

void serial_reset_read_buffer(void)
{
  serial_rx_buffer_tail = serial_rx_buffer_head;
}

//#ifdef __cplusplus 
//extern "C" {
//#endif
//void UART1_IRQHandler(void)                           // USART1����жϷ�����
//{
////	if(UART_GetITStatus(UART1, UART_IT_RXIEN) != RESET) //UART1�����ж�
////	{
////////  uint8_t data = UART1->RDR;
////////  uint8_t next_head;

////////  // Pick off realtime command characters directly from the serial stream. These characters are
////////  // not passed into the main buffer, but these set system state flag bits for realtime execution.
////////  switch (data) {
////////    case CMD_RESET:         mc_reset(); break; // Call motion control reset routine.
////////    case CMD_STATUS_REPORT: system_set_exec_state_flag(EXEC_STATUS_REPORT); break; // Set as true
////////    case CMD_CYCLE_START:   system_set_exec_state_flag(EXEC_CYCLE_START); break; // Set as true
////////    case CMD_FEED_HOLD:     system_set_exec_state_flag(EXEC_FEED_HOLD); break; // Set as true
////////    default :
////////      if (data > 0x7F) { // Real-time control characters are extended ACSII only.
////////        switch(data) {
////////          case CMD_SAFETY_DOOR:   system_set_exec_state_flag(EXEC_SAFETY_DOOR); break; // Set as true
////////          case CMD_JOG_CANCEL:   
////////            if (sys.state & STATE_JOG) { // Block all other states from invoking motion cancel.
////////              system_set_exec_state_flag(EXEC_MOTION_CANCEL); 
////////            }
////////            break; 
////////          #ifdef DEBUG
////////            case CMD_DEBUG_REPORT: {uint8_t sreg = SREG; cli(); bit_true(sys_rt_exec_debug,EXEC_DEBUG_REPORT); SREG = sreg;} break;
////////          #endif
////////          case CMD_FEED_OVR_RESET: system_set_exec_motion_override_flag(EXEC_FEED_OVR_RESET); break;
////////          case CMD_FEED_OVR_COARSE_PLUS: system_set_exec_motion_override_flag(EXEC_FEED_OVR_COARSE_PLUS); break;
////////          case CMD_FEED_OVR_COARSE_MINUS: system_set_exec_motion_override_flag(EXEC_FEED_OVR_COARSE_MINUS); break;
////////          case CMD_FEED_OVR_FINE_PLUS: system_set_exec_motion_override_flag(EXEC_FEED_OVR_FINE_PLUS); break;
////////          case CMD_FEED_OVR_FINE_MINUS: system_set_exec_motion_override_flag(EXEC_FEED_OVR_FINE_MINUS); break;
////////          case CMD_RAPID_OVR_RESET: system_set_exec_motion_override_flag(EXEC_RAPID_OVR_RESET); break;
////////          case CMD_RAPID_OVR_MEDIUM: system_set_exec_motion_override_flag(EXEC_RAPID_OVR_MEDIUM); break;
////////          case CMD_RAPID_OVR_LOW: system_set_exec_motion_override_flag(EXEC_RAPID_OVR_LOW); break;
////////          case CMD_SPINDLE_OVR_RESET: system_set_exec_accessory_override_flag(EXEC_SPINDLE_OVR_RESET); break;
////////          case CMD_SPINDLE_OVR_COARSE_PLUS: system_set_exec_accessory_override_flag(EXEC_SPINDLE_OVR_COARSE_PLUS); break;
////////          case CMD_SPINDLE_OVR_COARSE_MINUS: system_set_exec_accessory_override_flag(EXEC_SPINDLE_OVR_COARSE_MINUS); break;
////////          case CMD_SPINDLE_OVR_FINE_PLUS: system_set_exec_accessory_override_flag(EXEC_SPINDLE_OVR_FINE_PLUS); break;
////////          case CMD_SPINDLE_OVR_FINE_MINUS: system_set_exec_accessory_override_flag(EXEC_SPINDLE_OVR_FINE_MINUS); break;
////////          case CMD_SPINDLE_OVR_STOP: system_set_exec_accessory_override_flag(EXEC_SPINDLE_OVR_STOP); break;
////////          case CMD_COOLANT_FLOOD_OVR_TOGGLE: system_set_exec_accessory_override_flag(EXEC_COOLANT_FLOOD_OVR_TOGGLE); break;
////////          #ifdef ENABLE_M7
////////            case CMD_COOLANT_MIST_OVR_TOGGLE: system_set_exec_accessory_override_flag(EXEC_COOLANT_MIST_OVR_TOGGLE); break;
////////          #endif
////////        }
////////        // Throw away any unfound extended-ASCII character by not passing it to the serial buffer.
////////      } else { // Write character to buffer
////////        next_head = serial_rx_buffer_head + 1;
////////        if (next_head == RX_RING_BUFFER) { next_head = 0; }

////////        // Write data to buffer unless it is full.
////////        if (next_head != serial_rx_buffer_tail) {
////////          serial_rx_buffer[serial_rx_buffer_head] = data;
////////          serial_rx_buffer_head = next_head;
////////        }
////////      }
////////  }
//	UART_ClearITPendingBit(UART1,UART_IT_RXIEN);
////	}	
//	
//	// Data Register Empty Interrupt handler
////	if(UART_GetITStatus(UART1, UART_IT_TXIEN) == SET) // USART1���ͼĴ���Ϊ���ж�
////	{
////		uint8_t tail = serial_tx_buffer_tail; // Temporary serial_tx_buffer_tail (to optimize for volatile)

////		// Send a byte from the buffer
////		UART1->TDR = serial_tx_buffer[tail];

////		// Update tail position
////		tail++;
////		if (tail == TX_RING_BUFFER) { tail = 0; }

////		serial_tx_buffer_tail = tail;

////		// Turn off Data Register Empty Interrupt to stop tx-streaming if this concludes the transfer
////		if (tail == serial_tx_buffer_head)
////			{
////				UART_ITConfig(UART1, UART_IT_TXIEN , DISABLE);// ������ڷ��ͻ�����βָ��ָ��ͷָ��,˵�����������ݷ������,�ر�USART1���ͼĴ���Ϊ���ж�
////			}
////		UART_ClearITPendingBit(UART1,UART_IT_TXIEN);
////	}
//}
//#ifdef __cplusplus
//}
//#endif