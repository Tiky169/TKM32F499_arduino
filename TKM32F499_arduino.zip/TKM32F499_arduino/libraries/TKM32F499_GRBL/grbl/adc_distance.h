#include "grbl.h" 

#define ADC_CURROR   4095
void  Adc_Init(void);
u16 Get_Adc(u8 ch);
