#include "TK499_Application.h"

TK80_LCD:: TK80_LCD(u16 LCD_Reset_PIN,u16 Back_light_pin,u16 XSIZE_PHYS,u16 YSIZE_PHYS,u16 LCD_Model)
{
	_XSIZE_PHYS=XSIZE_PHYS;
	_YSIZE_PHYS=YSIZE_PHYS;
	_LCD_Reset_PIN = LCD_Reset_PIN;
	_LCD_Model = LCD_Model;
	textsize=1;
}
void TK80_LCD:: begin(void)
{
	LCD_TK80_init();  //初始化液晶屏相关GPIO
	LCD_Reset();      //复位液晶屏
	LCD_Initial();
	GPIO_SetBits(GPIOD, GPIO_Pin_8);	//open back light
	
}
/***************************************************************************************
** Function name:           width
** Description:             Return the pixel width of display (per current rotation)
***************************************************************************************/
// Return the size of the display (per current rotation)
u16 TK80_LCD::width(void)
{
  return _XSIZE_PHYS;
}


/***************************************************************************************
** Function name:           height
** Description:             Return the pixel height of display (per current rotation)
***************************************************************************************/
u16 TK80_LCD::height(void)
{
  return _YSIZE_PHYS;
}
/***************************************************************************************
** Function name:           color565
** Description:             convert three 8 bit RGB levels to a 16 bit colour value
***************************************************************************************/
u32 TK80_LCD::color888(u8 r, u8 g, u8 b)
{
  return (r<<16) | (g<<8) | b;
}
void TK80_LCD::TK80_DMA_Init(u32 srcAdd ,u32 len)	 //TK80的DMA配置函数，srcAdd是源地址，len是数据长度，一次能搬运42亿点
{   
	DMA2_Channel2->CNDTR = len;
	DMA2_Channel2->CMAR = srcAdd;
	DMA2_Channel2->CCR |= 1;
	TK80->CR |= 1;
} 
/*
初始化各种IO口，包括TK80接口初始化
*/
void TK80_LCD::LCD_TK80_init(void) 
{
	GPIO_InitTypeDef GPIO_InitStructure;//定义GPIO初始化结构体变量
	
	RCC->AHB2ENR |= RCC_AHB2Periph_TK80;    //打开 TK80 clock
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA | RCC_AHBPeriph_GPIOB | RCC_AHBPeriph_GPIOD | RCC_AHBPeriph_GPIOE | RCC_AHBPeriph_DMA2, ENABLE);
	
	// CS=PB11, RS=PB10, WR=PB9, RD=PB8
	GPIO_InitStructure.GPIO_Pin  =  GPIO_Pin_8 | GPIO_Pin_9 | GPIO_Pin_10 | GPIO_Pin_11;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	//PE0~PE23在用24位1600万色时，全部作为液晶屏数据线;如果是用18位，则只需要初始化低18位;如果是用16位，则只初始化16位，以此类推
  GPIO_InitStructure.GPIO_Pin  =  GPIO_Pin_All;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
  GPIO_Init(GPIOE, &GPIO_InitStructure);
	
	GPIO_PinAFConfig(GPIOB, GPIO_Pin_8 | GPIO_Pin_9 | GPIO_Pin_10 | GPIO_Pin_11, GPIO_AF_TK80_SDIO); //PB8~11复用为TK80的控制信号线
	GPIO_PinAFConfig(GPIOE, GPIO_Pin_All, GPIO_AF_TK80_SDIO); //GPIOE所有的IO全部复用为TK80的数据线

	//lcd_reset:PD6      LCD_Black_Light On Off  :PD8
	GPIO_InitStructure.GPIO_Pin  =  GPIO_Pin_6 | GPIO_Pin_8;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(GPIOD, &GPIO_InitStructure);
	
	//========== PA0 是五向按键的 中键 初始化为弱下接输入
	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_0;   
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;  
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	
	//TK80用的DMA2 准备成32位
	DMA2_Channel2->CCR = 0xa90;//  32位  16位=0x3590
	DMA2_Channel2->CPAR = (u32)&(TK80->DINR);

	TK80->CFGR1 = 0x050202;
    TK80->CFGR2 = 0x02;
}
void TK80_LCD::LCD_Reset()//液晶屏复位函数（通常触摸屏与液晶屏共用复位）
{
	pinMode(_LCD_Reset_PIN, OUTPUT);
	digitalWrite(_LCD_Reset_PIN, LOW);
	delay(250);				   
	digitalWrite(_LCD_Reset_PIN, HIGH);		 	 
	delay(250);
}

void TK80_LCD::WriteComm(unsigned short int CMD) //Write Command
{
	TK80->CMDIR = CMD;while(TK80->SR & 0x10000); 
}

void TK80_LCD::WriteData(unsigned int dat)     //Write Data
{
	TK80->DINR = dat;while(TK80->SR & 0x10000);
}
/***************************************************************************************
** Function name:           setRotation
** Description:             rotate the screen orientation m = 0-3 or 4-7 for BMP drawing
***************************************************************************************/
void TK80_LCD::setRotation(u8 m)
{
	if(_LCD_Model==TK035F5589_51)
	{
		WriteComm(0x36);
		switch(m)
		{
			case 0:
				WriteData(0x60);break ;
			case 1:
				WriteData(0x00);break ;
			case 2:
				WriteData(0xA0);break ;
			case 3:
				WriteData(0xC0);break ;
			default : break;
		}
	}
	if(_LCD_Model==TK024F3041)
	{
		WriteComm(0x36);
		switch(m)
		{
			case 0:
				WriteData(0x08);break ;
			case 1:
				WriteData(0x28);break ;
			case 2:
				WriteData(0xC8);break ;
			case 3:
				WriteData(0xE8);break ;
			default : break;
		}
	}
	if(_LCD_Model==TK043F1168)
	{
		WriteComm(0x36);
		switch(m)
		{
			case 0:
				WriteData(0x60);break ;
			case 1:
				WriteData(0x00);break ;
			case 2:
				WriteData(0xA0);break ;
			case 3:
				WriteData(0xC0);break ;
			default : break;
		}
	}
	
}
/***************************************************************************************
** Function name:           pushColor
** Description:             push a single pixel
***************************************************************************************/
void TK80_LCD::pushColor(u32 color)
{
  TK80->DINR = color;while(TK80->SR & 0x10000);
}
/***************************************************************************************
** Function name:           pushColor
** Description:             push a single colour to "len" pixels
***************************************************************************************/
void TK80_LCD::pushColor(u32 color, u16 len)
{
	TK80->CFGR3 = len;
	TK80->DINR = color;
	while(TK80->SR & 0x10000);
}
/******************************************
函数名：  Lcd write Command function
入口参数：Index :      Command
          ConfigTemp   Command parameter data
******************************************/
void TK80_LCD::LCD_WR_REG(u16 Index,u16 CongfigTemp)
{
	TK80->CMDIR = Index;
	while(TK80->SR & 0x10000);
	TK80->DINR = CongfigTemp;
	while(TK80->SR & 0x10000);
}
/**********************************************
set Addr Window

XStart  The starting point in the X-direction
Xend    The end point in the x-direction
YStart  The starting point in the Y-direction
Yend    The end point in the Y-direction

The meaning of this function is to open a rectangular box so that the data can be filled into this box later
***********************************************/
void TK80_LCD::setWindow(unsigned int Xstart,unsigned int Xend,unsigned int Ystart,unsigned int Yend) 
{
	WriteComm(0x2a);
	WriteData(Xstart>>8);
	WriteData(Xstart);
	WriteData(Xend>>8);
	WriteData(Xend);

	WriteComm(0x2b);   
	WriteData(Ystart>>8);
	WriteData(Ystart);
	WriteData(Yend>>8);
	WriteData(Yend);
	
	WriteComm(0x2c);
}
/***************************************************************************************
** Function name:           setAddrWindow
** Description:             define an area to receive a stream of pixels
***************************************************************************************/
// Chip select is high at the end of this function
void TK80_LCD::setAddrWindow(u16 x0, u16 y0, u16 w, u16 h)
{
  setWindow(x0, x0 + w - 1,y0,  y0 + h - 1);
}
/***************************************************************************************
** Function name:           setCursor
** Description:             Set the text cursor x,y position
***************************************************************************************/
void TK80_LCD::setCursor(u16 x, u16 y)
{
  cursor_x = x;
  cursor_y = y;
}
/***************************************************************************************
** Function name:           getCursorX
** Description:             Get the text cursor x position
***************************************************************************************/
u16 TK80_LCD::getCursorX(void)
{
  return cursor_x;
}

/***************************************************************************************
** Function name:           getCursorY
** Description:             Get the text cursor y position
***************************************************************************************/
u16 TK80_LCD::getCursorY(void)
{
  return cursor_y;
}
/***************************************************************************************
** Function name:           setTextSize
** Description:             Set the text size multiplier
***************************************************************************************/
void TK80_LCD::setTextSize(u8 s)
{
  textsize = s; 
}
/***************************************************************************************
** Function name:           setTextColor
** Description:             Set the font foreground colour (background is transparent)
***************************************************************************************/
void TK80_LCD::setTextColor(u32 c)
{
  // For 'transparent' background, we'll set the bg
  // to the same as fg instead of using a flag
  textcolor = c;
}


/***************************************************************************************
** Function name:           setTextColor
** Description:             Set the font foreground and background colour
***************************************************************************************/
void TK80_LCD::setTextColor(u32 c, u32 b)
{
  textcolor   = c;
  textbgcolor = b;
}
/***************************************************************************************
** Function name:           fillScreen
** Description:             Clear the screen to single colour
***************************************************************************************/
void TK80_LCD::fillScreen(uint32_t color)
{
	setWindow(0,_XSIZE_PHYS-1,0,_YSIZE_PHYS-1);
	TK80->CFGR3 = _XSIZE_PHYS*_YSIZE_PHYS;
	TK80->DINR = color;
	while(TK80->SR & 0x10000);
}
/**********************************************
rectangle fill function
XStart  The starting point in the X direction
YStart  The starting point in the Y direction
xLong   The x-direction length of the selected rectangle
yLong   The Y-direction length of the selected rectangle
***********************************************/
void TK80_LCD::fillRect(u16 xStart,u16 yStart,u16 xLong,u16 yLong,u32 Color)
{
	setWindow(xStart,xStart+xLong-1,yStart,yStart+yLong-1);
	TK80->CFGR3 = xLong*yLong;
	TK80->DINR = Color;
	while(TK80->SR & 0x10000);
}
/***************************************************************************************
** Function name:           drawRoundRect
** Description:             Draw a rounded corner rectangle outline
***************************************************************************************/
// Draw a rounded rectangle
void TK80_LCD::drawRoundRect(u16 x, u16 y, u16 w, u16 h, u8 r, uint32_t color)
{
  // smarter version
  drawHLine(x + r  , y    , w - r - r, color); // Top
  drawHLine(x + r  , y + h - 1, w - r - r, color); // Bottom
  drawVLine(x    , y + r  , h - r - r, color); // Left
  drawVLine(x + w - 1, y + r  , h - r - r, color); // Right
  // draw four corners
  drawCircleHelper(x + r    , y + r    , r, 1, color);
  drawCircleHelper(x + w - r - 1, y + r    , r, 2, color);
  drawCircleHelper(x + w - r - 1, y + h - r - 1, r, 4, color);
  drawCircleHelper(x + r    , y + h - r - 1, r, 8, color);
}


/***************************************************************************************
** Function name:           fillRoundRect
** Description:             Draw a rounded corner filled rectangle
***************************************************************************************/
// Fill a rounded rectangle, changed to horizontal lines (faster in sprites)
void TK80_LCD::fillRoundRect(u16 x, u16 y, u16 w, u16 h, u8 r, uint32_t color)
{
	//note : w - r - r - 1 >0 
  // smarter version
  fillRect(x, y + r, w, h - r - r, color);

  // draw four corners
  fillCircleHelper(x + r, y + h - r - 1, r, 1, w - r - r - 1, color);
  fillCircleHelper(x + r    , y + r, r, 2, w - r - r - 1, color);

}
void TK80_LCD::LCD_Initial(void) //LCD初始化函数
{
	if(_LCD_Model==TK035F5589_51)
	{
		WriteComm(0xB0);
		WriteData(0x04);
		 
		WriteComm(0xB4);    
		WriteData(0x00); 
		 
		WriteComm(0xC0);
		WriteData(0x03);//0013
		WriteData(0xDF);//480
		WriteData(0x40);
		WriteData(0x12);
		WriteData(0x00);
		WriteData(0x01);
		WriteData(0x00);
		WriteData(0x43);
		 
		 
		WriteComm(0xC1);//frame frequency
		WriteData(0x05);//BCn,DIVn[1:0
		WriteData(0x2f);//RTNn[4:0] 
		WriteData(0x08);// BPn[7:0]
		WriteData(0x08);// FPn[7:0]
		WriteData(0x00);
		 
		 
		 
		WriteComm(0xC4);
		WriteData(0x63);
		WriteData(0x00);
		WriteData(0x08);
		WriteData(0x08);
		 
		 WriteComm(0xC8);//Gamma
		WriteData(0x06);
		WriteData(0x0c);
		WriteData(0x16);
		WriteData(0x24);//26
		WriteData(0x30);//32 
		WriteData(0x48);
		WriteData(0x3d);
		WriteData(0x28);
		WriteData(0x20);
		WriteData(0x14);
		WriteData(0x0c);
		WriteData(0x04);
		 
		WriteData(0x06);
		WriteData(0x0c);
		WriteData(0x16);
		WriteData(0x24);
		WriteData(0x30);
		WriteData(0x48);
		WriteData(0x3d);
		WriteData(0x28);
		WriteData(0x20);
		WriteData(0x14);
		WriteData(0x0c);
		WriteData(0x04);
		 
		 
		 
		WriteComm(0xC9);//Gamma
		WriteData(0x06);
		WriteData(0x0c);
		WriteData(0x16);
		WriteData(0x24);//26
		WriteData(0x30);//32 
		WriteData(0x48);
		WriteData(0x3d);
		WriteData(0x28);
		WriteData(0x20);
		WriteData(0x14);
		WriteData(0x0c);
		WriteData(0x04);
		 
		WriteData(0x06);
		WriteData(0x0c);
		WriteData(0x16);
		WriteData(0x24);
		WriteData(0x30);
		WriteData(0x48);
		WriteData(0x3d);
		WriteData(0x28);
		WriteData(0x20);
		WriteData(0x14);
		WriteData(0x0c);
		WriteData(0x04);
		 
		 
		 
		WriteComm(0xCA);//Gamma
		WriteData(0x06);
		WriteData(0x0c);
		WriteData(0x16);
		WriteData(0x24);//26
		WriteData(0x30);//32 
		WriteData(0x48);
		WriteData(0x3d);
		WriteData(0x28);
		WriteData(0x20);
		WriteData(0x14);
		WriteData(0x0c);
		WriteData(0x04);
		 
		WriteData(0x06);
		WriteData(0x0c);
		WriteData(0x16);
		WriteData(0x24);
		WriteData(0x30);
		WriteData(0x48);
		WriteData(0x3d);
		WriteData(0x28);
		WriteData(0x20);
		WriteData(0x14);
		WriteData(0x0c);
		WriteData(0x04);
		 
		 
		WriteComm(0xD0);
		WriteData(0x95);
		WriteData(0x06);
		WriteData(0x08);
		WriteData(0x10);
		WriteData(0x3f);
		 
		 
		WriteComm(0xD1);
		WriteData(0x02);
		WriteData(0x28);
		WriteData(0x28);
		WriteData(0x40);
		 
		WriteComm(0xE1);    
		WriteData(0x00);    
		WriteData(0x00);    
		WriteData(0x00);    
		WriteData(0x00);    
		WriteData(0x00);   
		WriteData(0x00);   
		 
		WriteComm(0xE2);    
		WriteData(0x80);    
		 
		WriteComm(0x2A);    
		WriteData(0x00);    
		WriteData(0x00);    
		WriteData(0x01);    
		WriteData(0x3F);    
		 
		WriteComm(0x2B);    
		WriteData(0x00);    
		WriteData(0x00);    
		WriteData(0x01);    
		WriteData(0xDF);    
		 
		WriteComm(0x11);
		 
		delay(50);
		 
		WriteComm(0x29);
		 
		WriteComm(0xC1);//frame frequency
		WriteData(0x05);//BCn,DIVn[1:0
		WriteData(0x2f);//RTNn[4:0] 
		WriteData(0x08);// BPn[7:0]
		WriteData(0x08);// FPn[7:0]
		WriteData(0x00);
		WriteComm(0x20);
			
		WriteComm(0x3A);    
		WriteData(0x77);	
		WriteComm(0x36);    
		WriteData(0x60); 
	}
	if(_LCD_Model==TK024F3041)
	{
		WriteComm(0xCB);  
		WriteData(0x39); 
		WriteData(0x2C); 
		WriteData(0x00); 
		WriteData(0x34); 
		WriteData(0x02); 

		WriteComm(0xCF);  
		WriteData(0x00); 
		WriteData(0XC1); 
		WriteData(0X30); 

		WriteComm(0xE8);  
		WriteData(0x85); 
		WriteData(0x00); 
		WriteData(0x78); 

		WriteComm(0xEA);  
		WriteData(0x00); 
		WriteData(0x00); 

		WriteComm(0xED);  
		WriteData(0x64); 
		WriteData(0x03); 
		WriteData(0X12); 
		WriteData(0X81); 

		WriteComm(0xF7);  
		WriteData(0x20); 


		WriteComm(0xC0);    //Power control 
		WriteData(0x23);   //VRH[5:0] 

		WriteComm(0xC1);    //Power control 
		WriteData(0x10);   //SAP[2:0];BT[3:0] 

		WriteComm(0xC5);    //VCM control 
		WriteData(0x3e);    //Contrast adjustment
		WriteData(0x28); 

		WriteComm(0xC7);    //VCM control2 
		WriteData(0x00);  //--

		WriteComm(0x36);    // Memory Access Control 
		WriteData(0x28); 
		WriteComm(0x21);
		WriteComm(0x3A);    
		WriteData(0x55); 

		WriteComm(0xB1);    
		WriteData(0x00);  
		WriteData(0x18); 

		WriteComm(0xB6);    // Display Function Control 
		WriteData(0x08); 
		WriteData(0x82);
		WriteData(0x27);  

		WriteComm(0xF2);    // 3Gamma Function Disable 
		WriteData(0x00); 

		WriteComm(0x26);    //Gamma curve selected 
		WriteData(0x01); 

		WriteComm(0xE0);    //Set Gamma 
		WriteData(0x0F); 
		WriteData(0x31); 
		WriteData(0x2B); 
		WriteData(0x0C); 
		WriteData(0x0E); 
		WriteData(0x08); 
		WriteData(0x4E); 
		WriteData(0xF1); 
		WriteData(0x37); 
		WriteData(0x07); 
		WriteData(0x10); 
		WriteData(0x03); 
		WriteData(0x0E); 
		WriteData(0x09); 
		WriteData(0x00); 

		WriteComm(0XE1);    //Set Gamma 
		WriteData(0x00); 
		WriteData(0x0E); 
		WriteData(0x14); 
		WriteData(0x03); 
		WriteData(0x11); 
		WriteData(0x07); 
		WriteData(0x31); 
		WriteData(0xC1); 
		WriteData(0x48); 
		WriteData(0x08); 
		WriteData(0x0F); 
		WriteData(0x0C); 
		WriteData(0x31); 
		WriteData(0x36); 
		WriteData(0x0F); 

		WriteComm(0x11);    //Exit Sleep 
		WriteComm(0x29);    //Display on 
		delay(50);

		WriteComm(0x3A); WriteData(0x55);
		WriteComm(0x36); WriteData(0x48);//D3 bits are inverted, RB exchange in RGB; D5 bits are inverted, switching horizontal and vertical screen; D6, D7 bits are mirror image of x and y axis
	}
	if(_LCD_Model==TK043F1168)
	{
		int i;
		WriteComm(0x2D); 
		for (i=0; i<=63; i++)
		{
		WriteData(i*8);   
		}

		for (i=0; i<=63; i++)
		{
		WriteData(i*4);   
		}

		for (i=0; i<=63; i++)
		{
		WriteData(i*8);   
		}
 

		WriteComm(0xB9); //Set_EXTC
		WriteData(0xFF);
		WriteData(0x83);
		WriteData(0x69);



		WriteComm(0xB1);  //Set Power 
		WriteData(0x85);
		WriteData(0x00);
		WriteData(0x34);
		WriteData(0x0A);
		WriteData(0x00);
		WriteData(0x0F);
		WriteData(0x0F);
		WriteData(0x2A);
		WriteData(0x32);
		WriteData(0x3F);
		WriteData(0x3F);
		WriteData(0x01); //update VBIAS
		WriteData(0x23);
		WriteData(0x01);
		WriteData(0xE6);
		WriteData(0xE6);
		WriteData(0xE6);
		WriteData(0xE6);
		WriteData(0xE6);

		WriteComm(0xB2); // SET Display 480x800
		WriteData(0x00);
		WriteData(0x20);
		WriteData(0x0A);
		WriteData(0x0A);
		WriteData(0x70);
		WriteData(0x00);
		WriteData(0xFF);
		WriteData(0x00);
		WriteData(0x00);
		WriteData(0x00);
		WriteData(0x00);
		WriteData(0x03);
		WriteData(0x03);
		WriteData(0x00);
		WriteData(0x01);

		WriteComm(0xB4); // SET Display 480x800
		WriteData(0x00);
		WriteData(0x18);
		WriteData(0x80);
		WriteData(0x10);
		WriteData(0x01);
		WriteComm(0xB6); // SET VCOM
		WriteData(0x2C);
		WriteData(0x2C);

		WriteComm(0xD5); //SET GIP
		WriteData(0x00);
		WriteData(0x05);
		WriteData(0x03);
		WriteData(0x00);
		WriteData(0x01);
		WriteData(0x09);
		WriteData(0x10);
		WriteData(0x80);
		WriteData(0x37);
		WriteData(0x37);
		WriteData(0x20);
		WriteData(0x31);
		WriteData(0x46);
		WriteData(0x8A);
		WriteData(0x57);
		WriteData(0x9B);
		WriteData(0x20);
		WriteData(0x31);
		WriteData(0x46);
		WriteData(0x8A);
		WriteData(0x57);
		WriteData(0x9B);
		WriteData(0x07);
		WriteData(0x0F);
		WriteData(0x02);
		WriteData(0x00);
		WriteComm(0xE0); //SET GAMMA
		WriteData(0x00);
		WriteData(0x08);
		WriteData(0x0D);
		WriteData(0x2D);
		WriteData(0x34);
		WriteData(0x3F);
		WriteData(0x19);
		WriteData(0x38);
		WriteData(0x09);
		WriteData(0x0E);
		WriteData(0x0E);
		WriteData(0x12);
		WriteData(0x14);
		WriteData(0x12);
		WriteData(0x14);
		WriteData(0x13);
		WriteData(0x19);
		WriteData(0x00);
		WriteData(0x08);

		WriteData(0x0D);
		WriteData(0x2D);
		WriteData(0x34);
		WriteData(0x3F);
		WriteData(0x19);
		WriteData(0x38);
		WriteData(0x09);
		WriteData(0x0E);
		WriteData(0x0E);
		WriteData(0x12);
		WriteData(0x14);
		WriteData(0x12);
		WriteData(0x14);
		WriteData(0x13);
		WriteData(0x19);
		WriteComm(0xC1); //set DGC
		WriteData(0x01); //enable DGC function
		WriteData(0x02); //SET R-GAMMA
		WriteData(0x08);
		WriteData(0x12);
		WriteData(0x1A);
		WriteData(0x22);
		WriteData(0x2A);
		WriteData(0x31);
		WriteData(0x36);
		WriteData(0x3F);
		WriteData(0x48);
		WriteData(0x51);
		WriteData(0x58);
		WriteData(0x60);
		WriteData(0x68);
		WriteData(0x70);
		WriteData(0x78);
		WriteData(0x80);
		WriteData(0x88);
		WriteData(0x90);
		WriteData(0x98);
		WriteData(0xA0);
		WriteData(0xA7);
		WriteData(0xAF);
		WriteData(0xB6);
		WriteData(0xBE);
		WriteData(0xC7);
		WriteData(0xCE);
		WriteData(0xD6);
		WriteData(0xDE);
		WriteData(0xE6);
		WriteData(0xEF);
		WriteData(0xF5);
		WriteData(0xFB);
		WriteData(0xFC);
		WriteData(0xFE);
		WriteData(0x8C);
		WriteData(0xA4);
		WriteData(0x19);
		WriteData(0xEC);
		WriteData(0x1B);
		WriteData(0x4C);

		WriteData(0x40);
		WriteData(0x02); //SET G-Gamma
		WriteData(0x08);
		WriteData(0x12);
		WriteData(0x1A);
		WriteData(0x22);
		WriteData(0x2A);
		WriteData(0x31);
		WriteData(0x36);
		WriteData(0x3F);
		WriteData(0x48);
		WriteData(0x51);
		WriteData(0x58);
		WriteData(0x60);
		WriteData(0x68);
		WriteData(0x70);
		WriteData(0x78);
		WriteData(0x80);
		WriteData(0x88);
		WriteData(0x90);
		WriteData(0x98);
		WriteData(0xA0);
		WriteData(0xA7);
		WriteData(0xAF);
		WriteData(0xB6);
		WriteData(0xBE);
		WriteData(0xC7);
		WriteData(0xCE);
		WriteData(0xD6);
		WriteData(0xDE);
		WriteData(0xE6);
		WriteData(0xEF);
		WriteData(0xF5);
		WriteData(0xFB);
		WriteData(0xFC);
		WriteData(0xFE);
		WriteData(0x8C);
		WriteData(0xA4);
		WriteData(0x19);
		WriteData(0xEC);
		WriteData(0x1B);
		WriteData(0x4C);
		WriteData(0x40);
		WriteData(0x02); //SET B-Gamma
		WriteData(0x08);
		WriteData(0x12);
		WriteData(0x1A);
		WriteData(0x22);
		WriteData(0x2A);
		WriteData(0x31);
		WriteData(0x36);
		WriteData(0x3F);
		WriteData(0x48);
		WriteData(0x51);
		WriteData(0x58);
		WriteData(0x60);
		WriteData(0x68);
		WriteData(0x70);
		WriteData(0x78);

		WriteData(0x80);
		WriteData(0x88);
		WriteData(0x90);
		WriteData(0x98);
		WriteData(0xA0);
		WriteData(0xA7);
		WriteData(0xAF);
		WriteData(0xB6);
		WriteData(0xBE);
		WriteData(0xC7);
		WriteData(0xCE);
		WriteData(0xD6);
		WriteData(0xDE);
		WriteData(0xE6);
		WriteData(0xEF);
		WriteData(0xF5);
		WriteData(0xFB);
		WriteData(0xFC);
		WriteData(0xFE);
		WriteData(0x8C);
		WriteData(0xA4);
		WriteData(0x19);
		WriteData(0xEC);
		WriteData(0x1B);
		WriteData(0x4C);
		WriteData(0x40);
		WriteComm(0x3A); //Set COLMOD
		WriteData(0x55);
		WriteComm(0x11); //Sleep Out
		delay(120);
		WriteComm(0x29); //Display On
				
		delay(100);
		WriteComm(0x3A); //pixel format setting
		WriteData(0x77); //55 is 565, that is, 16 bits; 66 is 666, that is, 18 bits, and 77 is 888, that is, 24 bits (Note: need to be able to support 24-bit LCD to set 77)
		WriteComm(0x36); 
		WriteData(0x60); //Switch to horizontal display
	}
	if(_LCD_Model==TK035F9629)
	{
		WriteComm(0x11);      // Sleep Out 
		delay(120);
		WriteComm(0xf0) ;         
		 
		WriteData(0xc3) ; 
		WriteComm(0xf0) ; 
		WriteData(0x96) ; 
		WriteComm(0x36); 
		WriteData(0x48); 
		WriteComm(0xB4); 
		WriteData(0x01); 
		WriteComm(0xB7) ; 
		WriteData(0xC6) ; 
		WriteComm(0xe8); 
		WriteData(0x40); 
		WriteData(0x8a); 
		WriteData(0x00); 
		WriteData(0x00); 
		WriteData(0x29); 
		WriteData(0x19); 
		WriteData(0xa5); 
		WriteData(0x33); 
		WriteComm(0xc1); 
		WriteData(0x06); 
		WriteComm(0xc2); 
		WriteData(0xa7); 
		WriteComm(0xc5); 
		WriteData(0x18); 
		WriteComm(0xe0);      //Positive Voltage Gamma Control 
		WriteData(0xf0); 
		WriteData(0x09); 
		WriteData(0x0b); 
		WriteData(0x06); 
		WriteData(0x04); 
		WriteData(0x15); 
		WriteData(0x2f); 
		WriteData(0x54); 
		WriteData(0x42); 
		WriteData(0x3c); 
		WriteData(0x17); 
		WriteData(0x14); 
		WriteData(0x18); 
		WriteData(0x1b);         

		WriteComm(0xe1);      //Negative Voltage Gamma Control 
		WriteData(0xf0); 
		WriteData(0x09); 
		WriteData(0x0b); 
		WriteData(0x06); 
		WriteData(0x04); 
		WriteData(0x03); 
		WriteData(0x2d); 
		WriteData(0x43); 
		WriteData(0x42); 
		WriteData(0x3b); 
		WriteData(0x16); 
		WriteData(0x14); 
		WriteData(0x17); 
		WriteData(0x1b); 
		WriteComm(0xf0); 
		WriteData(0x3c); 
		WriteComm(0xf0); 
		WriteData(0x69); 
		delay(120);
		WriteComm(0x29);      //Display ON 
		WriteComm(0x21); 
		WriteComm(0x3a); 	//t ver address	
		WriteData(0x55);//

		WriteComm(0x36); //Set_address_mode 
		WriteData(0x28); //Switch to horizontal display
	}

}
/******************************************
函数名：Lcd图像填充
功能：向Lcd指定位置填充图像
入口参数：
					(x,y): 图片左上角起始坐标
					(pic_H,pic_V): 图片的宽高
					 pic  指向存储图片数组的指针
******************************************/
void TK80_LCD::LCD_Fill_Pic(u16 x, u16 y,u16 pic_H, u16 pic_V, u32* pic)
{
	//DMA 方式
	setWindow(x,x+pic_H-1,y,y+pic_V-1);
	TK80_DMA_Init((u32)pic,pic_H*pic_V);//DMA初始化
	while((DMA2->ISR & 0x20)==0);
	DMA2->IFCR |=1<<5;
	
	//========= 轮询方式=========//
//  unsigned long i;
//	unsigned long j;
//	setWindow(x,x+pic_H-1,y,y+pic_V-1);
//	j= pic_H*pic_V;
//	for (i = 0; i <j; i++)  {TK80->DINR = pic[i];while(TK80->SR & 0x10000);}
}
//=============== 在x，y 坐标上打一个颜色为Color的点 ===============
void TK80_LCD::drawPixel(u16 x, u16 y, int Color)
{
	setWindow(x,x,y,y); 
  TK80->DINR = Color;						  
}
void TK80_LCD::_drawPixel(int16_t x, int16_t y, int Color)
{
	if(x<0)return;
	if(y<0)return;
	if(x>=_XSIZE_PHYS)return;
	if(y>=_YSIZE_PHYS)return;
	setWindow(x,x,y,y); 
  TK80->DINR = Color;						  
}
void TK80_LCD:: drawHLine(u16 x,u16 y,u16 w,u32 Color)
{
	setWindow(x,x+w-1,y,y);
	TK80->CFGR3 = w;
	TK80->DINR = Color;
	while(TK80->SR & 0x10000);
}
void TK80_LCD:: drawVLine(u16 x,u16 y,u16 h,u32 Color)
{
	setWindow(x,x,y,y+h-1);
	
	TK80->CFGR3 = h;
	TK80->DINR = Color;
	while(TK80->SR & 0x10000);
}
void TK80_LCD:: _drawHLine(int16_t x,int16_t y,u16 w,u32 Color)
{
	if(x>=_XSIZE_PHYS)return;
	if((y<0)|(y>=_YSIZE_PHYS))return;
	
	if(x<0)
		{
			if((x+w)>0){w=x+w;x=0;}
			else return;
		}
	
	if((x+w)>=_XSIZE_PHYS)w=_XSIZE_PHYS-x;
	
	
	setWindow(x,x+w-1,y,y);
	TK80->CFGR3 = w;
	TK80->DINR = Color;
	while(TK80->SR & 0x10000);
}
void TK80_LCD:: _drawVLine(int16_t x,int16_t y,u16 h,u32 Color)
{
	if(y>=_YSIZE_PHYS)return;
	if((x<0)|(x>=_XSIZE_PHYS))return;
	
	if(y<0)
		{
			if((y+h)>0){h=y+h;y=0;}
			else return;
		}

	
	if((y+h)>=_YSIZE_PHYS)h=_YSIZE_PHYS-y;
	
	setWindow(x,x,y,y+h-1);
	
	TK80->CFGR3 = h;
	TK80->DINR = Color;
	while(TK80->SR & 0x10000);
}
/***************************************************************************************
** Function name:           drawLine
** Description:             draw a line between 2 arbitrary points
***************************************************************************************/
// Bresenham's algorithm - thx wikipedia - speed enhanced by Bodmer to use
// an efficient FastH/V Line draw routine for line segments of 2 pixels or more
void TK80_LCD::drawLine(u16 x0, u16 y0, u16 x1, u16 y1, uint32_t color)
{

  //x+= _xDatum;             // Not added here, added by drawPixel & drawFastXLine
  //y+= _yDatum;

  bool steep = abs(y1 - y0) > abs(x1 - x0);
  if (steep) {
    swap_coord(x0, y0);
    swap_coord(x1, y1);
  }

  if (x0 > x1) {
    swap_coord(x0, x1);
    swap_coord(y0, y1);
  }

  int32_t dx = x1 - x0, dy = abs(y1 - y0);;

  int32_t err = dx >> 1, ystep = -1, xs = x0, dlen = 0;

  if (y0 < y1) ystep = 1;

  // Split into steep and not steep for H/V separation
  if (steep) {
    for (; x0 <= x1; x0++) {
      dlen++;
      err -= dy;
      if (err < 0) {
        if (dlen == 1) drawPixel(y0, xs, color);
        else drawVLine(y0, xs, dlen, color);
        dlen = 0;
        y0 += ystep; xs = x0 + 1;
        err += dx;
      }
    }
    if (dlen) drawVLine(y0, xs, dlen, color);
  }
  else
  {
    for (; x0 <= x1; x0++) {
      dlen++;
      err -= dy;
      if (err < 0) {
        if (dlen == 1) drawPixel(xs, y0, color);
        else drawHLine(xs, y0, dlen, color);
        dlen = 0;
        y0 += ystep; xs = x0 + 1;
        err += dx;
      }
    }
    if (dlen) drawHLine(xs, y0, dlen, color);
  }
}
/***************************************************************************************
** Function name:           drawCircle
** Description:             Draw a circle outline
***************************************************************************************/
// Optimised midpoint circle algorithm
void TK80_LCD::drawCircle(int16_t x0, int16_t y0, int16_t r, uint32_t color)
{
  if ( r <= 0 ) return;

    int32_t f     = 1 - r;
    int32_t ddF_y = -2 * r;
    int32_t ddF_x = 1;
    int32_t xs    = -1;
    int32_t xe    = 0;
    int32_t len   = 0;
    
    bool first = true;
	if((x0-r)<0 | (y0-r)<0 | (x0+r)>=_XSIZE_PHYS | (y0+r)>=_YSIZE_PHYS)
	{
    do {
				while (f < 0) 
					{
					++xe;
					f += (ddF_x += 2);
					}
				f += (ddF_y += 2);

      if (xe-xs>1) {
        if (first) {
          len = 2*(xe - xs)-1;
          _drawHLine(x0 - xe, y0 + r, len, color);
          _drawHLine(x0 - xe, y0 - r, len, color);
          _drawVLine(x0 + r, y0 - xe, len, color);
          _drawVLine(x0 - r, y0 - xe, len, color);
          first = false;
        }
        else {
          len = xe - xs++;
          _drawHLine(x0 - xe, y0 + r, len, color);
          _drawHLine(x0 - xe, y0 - r, len, color);
          _drawHLine(x0 + xs, y0 - r, len, color);
          _drawHLine(x0 + xs, y0 + r, len, color);

          _drawVLine(x0 + r, y0 + xs, len, color);
          _drawVLine(x0 + r, y0 - xe, len, color);
          _drawVLine(x0 - r, y0 - xe, len, color);
          _drawVLine(x0 - r, y0 + xs, len, color);
        }
      }
      else {
        ++xs;
        _drawPixel(x0 - xe, y0 + r, color);
        _drawPixel(x0 - xe, y0 - r, color);
        _drawPixel(x0 + xs, y0 - r, color);
        _drawPixel(x0 + xs, y0 + r, color);

        _drawPixel(x0 + r, y0 + xs, color);
        _drawPixel(x0 + r, y0 - xe, color);
        _drawPixel(x0 - r, y0 - xe, color);
        _drawPixel(x0 - r, y0 + xs, color);
      }
      xs = xe;
    } while (xe < --r);
	}
	else
	{
		do {
				while (f < 0) 
					{
					++xe;
					f += (ddF_x += 2);
					}
				f += (ddF_y += 2);

      if (xe-xs>1) {
        if (first) {
          len = 2*(xe - xs)-1;
          drawHLine(x0 - xe, y0 + r, len, color);
          drawHLine(x0 - xe, y0 - r, len, color);
          drawVLine(x0 + r, y0 - xe, len, color);
          drawVLine(x0 - r, y0 - xe, len, color);
          first = false;
        }
        else {
          len = xe - xs++;
          drawHLine(x0 - xe, y0 + r, len, color);
          drawHLine(x0 - xe, y0 - r, len, color);
          drawHLine(x0 + xs, y0 - r, len, color);
          drawHLine(x0 + xs, y0 + r, len, color);

          drawVLine(x0 + r, y0 + xs, len, color);
          drawVLine(x0 + r, y0 - xe, len, color);
          drawVLine(x0 - r, y0 - xe, len, color);
          drawVLine(x0 - r, y0 + xs, len, color);
        }
      }
      else {
        ++xs;
        drawPixel(x0 - xe, y0 + r, color);
        drawPixel(x0 - xe, y0 - r, color);
        drawPixel(x0 + xs, y0 - r, color);
        drawPixel(x0 + xs, y0 + r, color);

        drawPixel(x0 + r, y0 + xs, color);
        drawPixel(x0 + r, y0 - xe, color);
        drawPixel(x0 - r, y0 - xe, color);
        drawPixel(x0 - r, y0 + xs, color);
      }
      xs = xe;
    } while (xe < --r);
	}
}
/***************************************************************************************
** Function name:           fillCircle
** Description:             draw a filled circle
***************************************************************************************/
// Optimised midpoint circle algorithm, changed to horizontal lines (faster in sprites)
// Improved algorithm avoids repetition of lines
void TK80_LCD::fillCircle(u16 x0, u16 y0, int16_t r, uint32_t color)
{
  int32_t  x  = 0;
  int32_t  dx = 1;
  int32_t  dy = r+r;
  int32_t  p  = -(r>>1);

  drawHLine(x0 - r, y0, dy+1, color);

  while(x<r){

    if(p>=0) {
      drawHLine(x0 - x, y0 + r, dx, color);
      drawHLine(x0 - x, y0 - r, dx, color);
      dy-=2;
      p-=dy;
      r--;
    }

    dx+=2;
    p+=dx;
    x++;

    drawHLine(x0 - r, y0 + x, dy+1, color);
    drawHLine(x0 - r, y0 - x, dy+1, color);

  }
}
/***************************************************************************************
** Function name:           drawCircleHelper
** Description:             Support function for drawRoundRect()
***************************************************************************************/
void TK80_LCD::drawCircleHelper( u16 x0, u16 y0, u16 rr, u8 cornername, uint32_t color)
{
  if (rr <= 0) return;
  int32_t f     = 1 - rr;
  int32_t ddF_x = 1;
  int32_t ddF_y = -2 * rr;
  int32_t xe    = 0;
  int32_t xs    = 0;
  int32_t len   = 0;
  while (xe < rr--)
  {
    while (f < 0) {
      ++xe;
      f += (ddF_x += 2);
    }
    f += (ddF_y += 2);

    if (xe-xs==1) {
      if (cornername & 0x1) { // left top
        drawPixel(x0 - xe, y0 - rr, color);
        drawPixel(x0 - rr, y0 - xe, color);
      }
      if (cornername & 0x2) { // right top
        drawPixel(x0 + rr    , y0 - xe, color);
        drawPixel(x0 + xs + 1, y0 - rr, color);
      }
      if (cornername & 0x4) { // right bottom
        drawPixel(x0 + xs + 1, y0 + rr    , color);
        drawPixel(x0 + rr, y0 + xs + 1, color);
      }
      if (cornername & 0x8) { // left bottom
        drawPixel(x0 - rr, y0 + xs + 1, color);
        drawPixel(x0 - xe, y0 + rr    , color);
      }
    }
    else {
      len = xe - xs++;
      if (cornername & 0x1) { // left top
        drawHLine(x0 - xe, y0 - rr, len, color);
        drawVLine(x0 - rr, y0 - xe, len, color);
      }
      if (cornername & 0x2) { // right top
        drawVLine(x0 + rr, y0 - xe, len, color);
        drawHLine(x0 + xs, y0 - rr, len, color);
      }
      if (cornername & 0x4) { // right bottom
        drawHLine(x0 + xs, y0 + rr, len, color);
        drawVLine(x0 + rr, y0 + xs, len, color);
      }
      if (cornername & 0x8) { // left bottom
        drawVLine(x0 - rr, y0 + xs, len, color);
        drawHLine(x0 - xe, y0 + rr, len, color);
      }
    }
    xs = xe;
  }
}
/***************************************************************************************
** Function name:           fillCircleHelper
** Description:             Support function for fillRoundRect()
***************************************************************************************/
// Support drawing roundrects, changed to horizontal lines (faster in sprites)
void TK80_LCD::fillCircleHelper(u16 x0, u16 y0, u16 r, u8 cornername, u16 delta, uint32_t color)
{
  int16_t f     = 1 - r;
  int16_t ddF_x = 1;
  int16_t ddF_y = -r - r;
  int16_t y     = 0;

  delta++;

  while (y < r) {
    if (f >= 0) {
      if (cornername & 0x1) drawHLine(x0 - y, y0 + r, y + y + delta, color);
      if (cornername & 0x2) drawHLine(x0 - y, y0 - r, y + y + delta, color);
      r--;
      ddF_y += 2;
      f     += ddF_y;
    }

    y++;
    ddF_x += 2;
    f     += ddF_x;

    if (cornername & 0x1) drawHLine(x0 - r, y0 + y, r + r + delta, color);
    if (cornername & 0x2) drawHLine(x0 - r, y0 - y, r + r + delta, color);
  }
}

/***************************************************************************************
** Function name:           drawEllipse
** Description:             Draw a ellipse outline
***************************************************************************************/
void TK80_LCD::drawEllipse(u16 x0, u16 y0, u16 rx, u16 ry, uint32_t color)
{
  if (rx<2) return;
  if (ry<2) return;
  int32_t x, y;
  int32_t rx2 = rx * rx;
  int32_t ry2 = ry * ry;
  int32_t fx2 = 4 * rx2;
  int32_t fy2 = 4 * ry2;
  int32_t s;

  for (x = 0, y = ry, s = 2*ry2+rx2*(1-2*ry); ry2*x <= rx2*y; x++) {
    // These are ordered to minimise coordinate changes in x or y
    // drawPixel can then send fewer bounding box commands
    drawPixel(x0 + x, y0 + y, color);
    drawPixel(x0 - x, y0 + y, color);
    drawPixel(x0 - x, y0 - y, color);
    drawPixel(x0 + x, y0 - y, color);
    if (s >= 0) {
      s += fx2 * (1 - y);
      y--;
    }
    s += ry2 * ((4 * x) + 6);
  }

  for (x = rx, y = 0, s = 2*rx2+ry2*(1-2*rx); rx2*y <= ry2*x; y++) {
    // These are ordered to minimise coordinate changes in x or y
    // drawPixel can then send fewer bounding box commands
    drawPixel(x0 + x, y0 + y, color);
    drawPixel(x0 - x, y0 + y, color);
    drawPixel(x0 - x, y0 - y, color);
    drawPixel(x0 + x, y0 - y, color);
    if (s >= 0)
    {
      s += fy2 * (1 - x);
      x--;
    }
    s += rx2 * ((4 * y) + 6);
  }
}


/***************************************************************************************
** Function name:           fillEllipse
** Description:             draw a filled ellipse
***************************************************************************************/
void TK80_LCD::fillEllipse(u16 x0, u16 y0, u16 rx, u16 ry, uint32_t color)
{
  if (rx<2) return;
  if (ry<2) return;
  int32_t x, y;
  int32_t rx2 = rx * rx;
  int32_t ry2 = ry * ry;
  int32_t fx2 = 4 * rx2;
  int32_t fy2 = 4 * ry2;
  int32_t s;

  for (x = 0, y = ry, s = 2*ry2+rx2*(1-2*ry); ry2*x <= rx2*y; x++) {
    drawHLine(x0 - x, y0 - y, x + x + 1, color);
    drawHLine(x0 - x, y0 + y, x + x + 1, color);

    if (s >= 0) {
      s += fx2 * (1 - y);
      y--;
    }
    s += ry2 * ((4 * x) + 6);
  }

  for (x = rx, y = 0, s = 2*rx2+ry2*(1-2*rx); rx2*y <= ry2*x; y++) {
    drawHLine(x0 - x, y0 - y, x + x + 1, color);
    drawHLine(x0 - x, y0 + y, x + x + 1, color);

    if (s >= 0) {
      s += fy2 * (1 - x);
      x--;
    }
    s += rx2 * ((4 * y) + 6);
  }
}

/***************************************************************************************
** Function name:           drawTriangle
** Description:             Draw a triangle outline using 3 arbitrary points
***************************************************************************************/
// Draw a triangle
void TK80_LCD::drawTriangle(u16 x0, u16 y0, u16 x1, u16 y1, u16 x2, u16 y2, uint32_t color)
{
  drawLine(x0, y0, x1, y1, color);
  drawLine(x1, y1, x2, y2, color);
  drawLine(x2, y2, x0, y0, color);
}


/***************************************************************************************
** Function name:           fillTriangle
** Description:             Draw a filled triangle using 3 arbitrary points
***************************************************************************************/
// Fill a triangle - original Adafruit function works well and code footprint is small
void TK80_LCD::fillTriangle (u16 x0, u16 y0, u16 x1, u16 y1, u16 x2, u16 y2, uint32_t color)
{
  int32_t a, b, y, last;

  // Sort coordinates by Y order (y2 >= y1 >= y0)
  if (y0 > y1) {
    swap_coord(y0, y1); swap_coord(x0, x1);
  }
  if (y1 > y2) {
    swap_coord(y2, y1); swap_coord(x2, x1);
  }
  if (y0 > y1) {
    swap_coord(y0, y1); swap_coord(x0, x1);
  }

  if (y0 == y2) { // Handle awkward all-on-same-line case as its own thing
    a = b = x0;
    if (x1 < a)      a = x1;
    else if (x1 > b) b = x1;
    if (x2 < a)      a = x2;
    else if (x2 > b) b = x2;
    drawHLine(a, y0, b - a + 1, color);
    return;
  }

  int32_t
  dx01 = x1 - x0,
  dy01 = y1 - y0,
  dx02 = x2 - x0,
  dy02 = y2 - y0,
  dx12 = x2 - x1,
  dy12 = y2 - y1,
  sa   = 0,
  sb   = 0;

  // For upper part of triangle, find scanline crossings for segments
  // 0-1 and 0-2.  If y1=y2 (flat-bottomed triangle), the scanline y1
  // is included here (and second loop will be skipped, avoiding a /0
  // error there), otherwise scanline y1 is skipped here and handled
  // in the second loop...which also avoids a /0 error here if y0=y1
  // (flat-topped triangle).
  if (y1 == y2) last = y1;  // Include y1 scanline
  else         last = y1 - 1; // Skip it

  for (y = y0; y <= last; y++) {
    a   = x0 + sa / dy01;
    b   = x0 + sb / dy02;
    sa += dx01;
    sb += dx02;

    if (a > b) swap_coord(a, b);
    drawHLine(a, y, b - a + 1, color);
  }

  // For lower part of triangle, find scanline crossings for segments
  // 0-2 and 1-2.  This loop is skipped if y1=y2.
  sa = dx12 * (y - y1);
  sb = dx02 * (y - y0);
  for (; y <= y2; y++) {
    a   = x1 + sa / dy12;
    b   = x0 + sb / dy02;
    sa += dx12;
    sb += dx02;

    if (a > b) swap_coord(a, b);
    drawHLine(a, y, b - a + 1, color);
  }
}
size_t TK80_LCD::write(uint8_t utf8)
{
	static u8 UTF8_n=0,n=0,c[3];
	if(UTF8_n==0 && n==0)
	{
		if(utf8<0x80)
		{
			if (utf8 == '\r') return 1;
			if(utf8=='\n')
			{
				cursor_x=0;
				if(cursor_y<_YSIZE_PHYS-16-1) cursor_y+=16*textsize;
				else cursor_y=0;
			}
			else
			{
				drawChar(cursor_x,cursor_y,utf8,textcolor,textbgcolor,0);
				cursor_x+=8*textsize;
			}
		}
		else
		{
			c[0]=utf8;
			if ((utf8 & 0xE0) == 0xC0) //2 bye UTF8
			UTF8_n=2;
			if ((utf8 & 0xF0) == 0xE0) //3 bye UTF8
			UTF8_n=3;
			n=1;
		}
	}
	else if(n==1)
	{
		c[1]=utf8;
		if(UTF8_n==2) 
		{
			c[2]=0;
			draw_Chinese(cursor_x,cursor_y,c,textcolor,textbgcolor,0);
			cursor_x+=16*textsize;
			UTF8_n=0;
			n=0;
		}
		else 
		{
			n=2;
		}
	}
	else if(n==2)
	{
		c[2]=utf8;
		draw_Chinese(cursor_x,cursor_y,c,textcolor,textbgcolor,0);
		cursor_x+=16*textsize;
		UTF8_n=0;
		n=0;
	}
}
/**********8*16 ASCII Font display *************
(x,y):  The starting coordinates of the char
num:    The char's position of ASCII array table: " "--->"~"
fColor  Foreground color
bColor  Background color
flag:   1: display Background color,  0: no display Background color,means transparent display
*********************************************/
void TK80_LCD:: drawChar(unsigned short x,unsigned short y,unsigned char num, unsigned int fColor, unsigned int bColor,unsigned char flag) 
{       
	unsigned char temp;
	unsigned int pos,i,j,k,m=textsize*textsize;  

	num=num-' ';//Get the offset value
	i=num*16; 	
//	setWindow(x,x+8-1,y,y+16-1);
//	for(pos=0;pos<16;pos++)
//		{
//			temp=nAsciiDot[i+pos];	//ַCall the ASCII font
//			for(j=0;j<8;j++)
//		   {                 
//		        if(temp&0x80)
//							TK80->DINR = fColor;	
//						else 
//							TK80->DINR = bColor; 	
//							temp<<=1; 
//		    }
//			 y++;
//		}	
	
	for(pos=0;pos<16;pos++)
		{
			temp=nAsciiDot[i+pos];	//Call the ASCII font
			for(j=0;j<8;j++)
		   {                 
		        if(temp&0x80)
						{
								setWindow(x+j*textsize,x+j*textsize+textsize-1,y,y+textsize-1);
								for(k=0;k<m;k++)
								{
									WriteData(fColor);
								}
						}
						else 
							if(flag) 
							{
								setWindow(x+j*textsize,x+j*textsize+textsize-1,y,y+textsize-1);
								for(k=0;k<m;k++)
								{
									WriteData(bColor);
								}
							}
							temp<<=1; 
		    }
			 y+=textsize;
		}		 
}  

/********** write a 16x16 Chinese character *****************
(x,y): the starting coordinates of the Chinese character to be displayed
c[2]: the Chinese character to be displayed
fColor foreground view
bColor background color
flag: with background color (1) without background color (0)
*********************************************/
void TK80_LCD:: draw_Chinese(unsigned short x, unsigned short  y, unsigned char c[3], unsigned int fColor,unsigned int bColor,unsigned char flag)
{
	unsigned short i,j,k,m=textsize*textsize,h;
	unsigned short temp;
	for (k=0;k<64;k++) { //64 indicates the number of characters in the self-built Chinese character library, and the cyclic query of the internal code
	  if ((codeGB_16[k].Index[0]==c[0])&&(codeGB_16[k].Index[1]==c[1])&&(codeGB_16[k].Index[2]==c[2]))
			{ 
    	for(i=0;i<32;i++) 
			{
				temp=codeGB_16[k].Msk[i];
				for(j=0;j<8;j++) 
				{		
					if(temp&0x80)
						{
								setWindow(x+j*textsize,x+j*textsize+textsize-1,y,y+textsize-1);
								for(h=0;h<m;h++)
								{
									WriteData(fColor);
								}
						}
						else 
							if(flag) 
							{
								setWindow(x+j*textsize,x+j*textsize+textsize-1,y,y+textsize-1);
								for(h=0;h<m;h++)
								{
									WriteData(bColor);
								}
							}
					temp=temp<<1;
				} 
				if(i%2){y+=textsize;x=x-8*textsize;}
				else x=x+8*textsize;
		  }
		}  
	  }	
	}
/********** displays  strings *****************
(x,y): coordinates of the start of the string
*s: pointer to the string to be displayed
fColor foreground view
bColor background color
flag: with background color (1) without background color (0)
*********************************************/
void TK80_LCD:: drawString(unsigned short x, unsigned short y, char *s, unsigned int fColor, unsigned int bColor,unsigned char flag) 
	{
		unsigned char l=0;//,ch[3]
		while(*s) 
			{
				if( (unsigned char)*s < 0x80) 
						{
							drawChar(x+l*8,y,*s,fColor,bColor,flag);
							s++;l+=textsize;
						}
				else
						{
							// 11 bit Unicode Code 
							if ((*s & 0xE0) == 0xC0) 
							{
								//ch[0] =	(*s&0x1f)>>2;
								//ch[1] =	((*s&0x3)<<6)|(*(s+1)&0x3f);
								draw_Chinese(x+l*8,y,(unsigned char *)s,fColor,bColor,flag);
								s+=2;l+=2*textsize;
							}
							// 16 bit Unicode Code
							if ((*s & 0xF0) == 0xE0) 
							{
								//ch[0] =	((*s&0xf)<<4) | ((*(s+1)&0x3c)>>2);
								//ch[1] =	((*(s+1)&0x3)<<6) | (*(s+2)&0x3f);
								draw_Chinese(x+l*8,y,(unsigned char *)s,fColor,bColor,flag);
								s+=3;l+=2*textsize;
							}
						}
			}
	}