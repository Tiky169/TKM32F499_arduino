#ifndef _TK499_Application_
#define _TK499_Application_
#include "Arduino.h"
#include "TK499.h"
#include "HAL_conf.h"
#include "ASCII.h"
#include "GB1616.h"	//16*16汉字字模
#include <Print.h>
#define Set_Rst GPIOD->BSRR = GPIO_Pin_6
#define Clr_Rst GPIOD->BRR  = GPIO_Pin_6

#define TK035F5589     0
#define TK035F5589_51  1
#define TK043F1168     2
#define TK024F3041     3
#define TK024F3089     4
#define TK043F1508     5
#define TK028F4418     6
#define TK028F4419     7
#define TK050F9039     8
#define IPS1P1400      9
#define IPS3P2524      10
#define IPS1P1399      11
#define TK035F9629      11

//*************  24位色（1600万色）定义 24bit color*************//
#define WHITE          0xFFFFFF
#define BLACK          0x000000
#define BLUE           0x0000FF
#define BLUE2          0x3F3FFF
#define RED            0xFF0000
#define MAGENTA        0xFF00FF
#define GREEN          0x00FF00
#define CYAN           0x00FFFF
#define YELLOW         0xFFFF00	

////*************  16位色定义 16bit color*************//
#define WHITE_16          0xFFFF
#define BLACK_16          0x0000
#define BLUE_16           0x001F
#define BLUE2_16          0x051F
#define RED_16            0xF800
#define MAGENTA_16        0xF81F
#define GREEN_16          0x07E0
#define CYAN_16           0x7FFF
#define YELLOW_16         0xFFE0

// Swap any type
template <typename T> static inline void
swap_coord(T& a, T& b) { T t = a; a = b; b = t; }

class TK80_LCD : public Print
{
	public:

		TK80_LCD(u16 LCD_Reset_PIN,u16 Back_light_pin,u16 XSIZE_PHYS,u16 YSIZE_PHYS,u16 LCD_Model);
		void begin(void);
		u16 height(void),
				width(void);
		u32 color888(u8 r, u8 g, u8 b);
		void LCD_Initial(void);
		void pushColor(u32 color);
		void pushColor(u32 color, u16 len);
		void setRotation(u8 m);
		void setWindow(unsigned int Xstart,unsigned int Xend,unsigned int Ystart,unsigned int Yend);
		void setAddrWindow(u16 x0, u16 y0, u16 w, u16 h);
	
		// Text rendering and font handling support funtions
		void setCursor(u16 x, u16 y);                 // Set cursor for tft.print()


		u16  getCursorX(void),                                // Read current cursor x position (moves with tft.print())
         getCursorY(void);                                // Read current cursor y position
		void setTextSize(u8 s);
           
		void   setTextColor(u32 color),                    // Set character (glyph) color only (background not over-written)
           setTextColor(u32 fgcolor, u32 bgcolor);// Set character (glyph) foreground and backgorund colour
	
		void fillScreen(uint32_t color);
		void fillRect(u16 xStart,u16 yStart,u16 xLong,u16 yLong,u32 Color);
		void drawRoundRect(u16 x, u16 y, u16 w, u16 h, u8 radius, uint32_t color);
    void fillRoundRect(u16 x, u16 y, u16 w, u16 h, u8 radius, uint32_t color);
	
	
		void LCD_Fill_Pic(u16 x, u16 y,u16 pic_H, u16 pic_V, u32* pic);
		void drawPixel(u16 x, u16 y, int Color);
		
		void drawHLine(u16 x,u16 y,u16 w,u32 Color);
		void drawVLine(u16 x,u16 y,u16 h,u32 Color);
		void drawLine(u16 x0, u16 y0, u16 x1, u16 y1, uint32_t color);
	
		void drawCircle(int16_t x, int16_t y, int16_t r, uint32_t color);
		void fillCircle(u16 x, u16 y, int16_t r, uint32_t color);
		void drawCircleHelper( u16 x0, u16 y0, u16 rr, u8 cornername, uint32_t color);
		void fillCircleHelper(u16 x0, u16 y0, u16 r, u8 cornername, u16 delta, uint32_t color);
	
		void drawEllipse(u16 x, u16 y, u16 rx, u16 ry, uint32_t color);
    void fillEllipse(u16 x, u16 y, u16 rx, u16 ry, uint32_t color);
		//                 Corner 1      Corner 2       Corner 3
    void drawTriangle(u16 x1,u16 y1, u16 x2,u16 y2, u16 x3,u16 y3, uint32_t color),
         fillTriangle(u16 x1,u16 y1, u16 x2,u16 y2, u16 x3,u16 y3, uint32_t color);
		size_t write(uint8_t utf8);
		void drawChar(unsigned short x,unsigned short y,unsigned char num, unsigned int fColor, unsigned int bColor,unsigned char flag);
		void draw_Chinese(unsigned short x, unsigned short  y, unsigned char c[3], unsigned int fColor,unsigned int bColor,unsigned char flag);
		void drawString(unsigned short x, unsigned short y, char *s, unsigned int fColor, unsigned int bColor,unsigned char flag);	
		
	private:
		u16 _XSIZE_PHYS,_YSIZE_PHYS,_LCD_Model;
		u8 textsize;
		unsigned short int _LCD_Reset_PIN;
		void LCD_TK80_init(void);
		void LCD_Reset();
		void WriteComm(unsigned short int CMD);
		void WriteData(unsigned int dat);
		void _drawHLine(int16_t x,int16_t y,u16 w,u32 Color);
		void _drawVLine(int16_t x,int16_t y,u16 h,u32 Color);
		void _drawPixel(int16_t x, int16_t y, int Color);
		void LCD_WR_REG(u16 Index,u16 CongfigTemp);
		void TK80_DMA_Init(u32 srcAdd ,u32 len);
	protected:
		u32 textcolor, textbgcolor;    // Text foreground and background colours
		u16  cursor_x, cursor_y;       // Text cursor x,y
};

#endif