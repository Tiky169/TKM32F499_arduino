#ifndef __SYS_H
#define __SYS_H	 
#include "tk499.h" 
#include "HAL_conf.h"
//Bitband operation to achieve similar GPIO control function of 51
//M4 is similar to M3, but the register address has changed.
// IO port operation macro definition
#define BITBAND(addr, bitnum) ((addr & 0xF0000000)+0x2000000+((addr &0xFFFFF)<<5)+(bitnum<<2)) 
#define MEM_ADDR(addr)  *((volatile unsigned long  *)(addr)) 
#define BIT_ADDR(addr, bitnum)   MEM_ADDR(BITBAND(addr, bitnum)) 

void  RemapVtorTable(void);
void  AI_Responder_enable(void);
void  AI_Responder_disable(void);
void  AI_Responder_refresh(void);

void Sys_Soft_Reset(void);      							//System soft reset 
void Sys_Standby(void);         							//standby mode	

void TK499_NVIC_Init(u8 NVIC_PreemptionPriority,u8 NVIC_SubPriority,u8 NVIC_Channel,u8 NVIC_Group);	
void Ex_NVIC_Config(GPIO_TypeDef* GPIOx,uint32_t GPIO_Pin,u8 TRIM);				//External interrupt configuration function (only for GPIOA~E)

//The following are assembly functions
void WFI_SET(void);		
void INTX_DISABLE(void);
void INTX_ENABLE(void);	

#endif











